package model;

public class UGStudent extends Student {
    private String specialization;

    public UGStudent() {
    }

    public UGStudent(String var1, String var2, String var3, int var4, String var5, String var6, int var7, double var8, String var10) {
        super(var1, var2, var3, var4, var5, var6, var7, var8);
        this.specialization = var10;
    }

    public String getSpecialization() {
        return this.specialization;
    }

    public void setSpecialization(String var1) {
        this.specialization = var1;
    }

    public void displayDetails() {
        super.displayDetails();
        System.out.println("Specialization: " + this.specialization);
    }
}
