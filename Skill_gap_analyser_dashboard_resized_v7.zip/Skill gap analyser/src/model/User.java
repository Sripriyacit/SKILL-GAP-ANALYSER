package model;

/**
 * Represents a registered user of the Skill Gap Analyser web
 * application: their login credentials plus the academic
 * profile collected at registration.
 */
public class User {

    private final String fullName;
    private final String email;
    private final String username;
    private final String passwordHash;

    private final String age;
    private final String qualification;
    private final String collegeName;
    private final String department;
    private final String semester;
    private final String cgpa;

    public User(String fullName, String email, String username, String passwordHash,
                String age, String qualification, String collegeName,
                String department, String semester, String cgpa) {

        this.fullName = fullName;
        this.email = email;
        this.username = username;
        this.passwordHash = passwordHash;

        this.age = age;
        this.qualification = qualification;
        this.collegeName = collegeName;
        this.department = department;
        this.semester = semester;
        this.cgpa = cgpa;
    }

    public String getFullName() {
        return fullName;
    }

    public String getEmail() {
        return email;
    }

    public String getUsername() {
        return username;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public String getAge() {
        return age;
    }

    public String getQualification() {
        return qualification;
    }

    public String getCollegeName() {
        return collegeName;
    }

    public String getDepartment() {
        return department;
    }

    public String getSemester() {
        return semester;
    }

    public String getCgpa() {
        return cgpa;
    }
}
