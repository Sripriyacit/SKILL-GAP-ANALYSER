
package model;

/**
 * Represents the difference between a student's
 * current skill level and the required skill level
 * for a particular career.
 */
public class SkillGap {

    private String skillName;

    private int currentScore;

    private int requiredScore;

    private int gap;


    // =========================================================
    // CONSTRUCTOR
    // =========================================================

    public SkillGap(
            String skillName,
            int currentScore,
            int requiredScore
    ) {

        this.skillName =
                skillName;

        this.currentScore =
                currentScore;

        this.requiredScore =
                requiredScore;

        calculateGap();
    }


    // =========================================================
    // GET SKILL NAME
    // =========================================================

    public String getSkillName() {

        return skillName;
    }


    // =========================================================
    // SET SKILL NAME
    // =========================================================

    public void setSkillName(
            String skillName
    ) {

        this.skillName =
                skillName;
    }


    // =========================================================
    // GET CURRENT SCORE
    // =========================================================

    public int getCurrentScore() {

        return currentScore;
    }


    // =========================================================
    // GET CURRENT
    // =========================================================

    /*
     * Compatibility method.
     * Used by GapAnalyzer.
     */

    public int getCurrent() {

        return currentScore;
    }


    // =========================================================
    // SET CURRENT SCORE
    // =========================================================

    public void setCurrentScore(
            int currentScore
    ) {

        this.currentScore =
                currentScore;

        calculateGap();
    }


    // =========================================================
    // SET CURRENT
    // =========================================================

    public void setCurrent(
            int current
    ) {

        this.currentScore =
                current;

        calculateGap();
    }


    // =========================================================
    // GET REQUIRED SCORE
    // =========================================================

    public int getRequiredScore() {

        return requiredScore;
    }


    // =========================================================
    // GET REQUIRED
    // =========================================================

    /*
     * Compatibility method.
     * Used if GapAnalyzer calls getRequired().
     */

    public int getRequired() {

        return requiredScore;
    }


    // =========================================================
    // SET REQUIRED SCORE
    // =========================================================

    public void setRequiredScore(
            int requiredScore
    ) {

        this.requiredScore =
                requiredScore;

        calculateGap();
    }


    // =========================================================
    // SET REQUIRED
    // =========================================================

    public void setRequired(
            int required
    ) {

        this.requiredScore =
                required;

        calculateGap();
    }


    // =========================================================
    // GET GAP
    // =========================================================

    public int getGap() {

        return gap;
    }


    // =========================================================
    // SET GAP
    // =========================================================

    public void setGap(
            int gap
    ) {

        this.gap =
                Math.max(
                        0,
                        gap
                );
    }


    // =========================================================
    // GET STATUS
    // =========================================================

    /**
     * Returns the current status of the skill.
     *
     * @return "Achieved" if the current score
     *         meets or exceeds the required score,
     *         otherwise "Needs Improvement"
     */
    public String getStatus() {

        if (currentScore >= requiredScore) {

            return "Achieved";

        } else {

            return "Needs Improvement";
        }
    }


    // =========================================================
    // CALCULATE GAP
    // =========================================================

    private void calculateGap() {

        /*
         * Calculate how many points the student
         * needs to improve.
         *
         * Example:
         *
         * Current = 40
         * Required = 80
         * Gap = 40
         *
         * If Current = 90 and Required = 80,
         * Gap = 0.
         */

        this.gap =
                Math.max(
                        0,
                        requiredScore - currentScore
                );
    }


    // =========================================================
    // TO STRING
    // =========================================================

    @Override
    public String toString() {

        return "SkillGap{" +
                "skillName='" +
                skillName +
                '\'' +
                ", currentScore=" +
                currentScore +
                ", requiredScore=" +
                requiredScore +
                ", gap=" +
                gap +
                ", status='" +
                getStatus() +
                '\'' +
                '}';
    }
}
