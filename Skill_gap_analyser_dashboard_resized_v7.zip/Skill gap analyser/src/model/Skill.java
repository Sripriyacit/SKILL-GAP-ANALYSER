package model;

public class Skill {
    private final String skillId;
    private String skillName;
    private int skillScore;

    public Skill(String var1, String var2, int var3) {
        this.skillId = var1;
        this.skillName = var2;
        this.skillScore = var3;
    }

    public String getSkillId() {
        return this.skillId;
    }

    public String getSkillName() {
        return this.skillName;
    }

    public void setSkillName(String var1) {
        this.skillName = var1;
    }

    public int getSkillScore() {
        return this.skillScore;
    }

    public void setSkillScore(int var1) {
        this.skillScore = var1;
    }

    public String toString() {
        return this.skillName + " : " + this.skillScore + "/100";
    }
}
