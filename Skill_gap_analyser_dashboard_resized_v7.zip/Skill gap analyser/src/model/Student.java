package model;

import java.util.ArrayList;
import java.util.List;

public class Student extends Person implements Cloneable {
    private String collegeName;
    private int semester;
    private double cgpa;
    private final ArrayList<Skill> skills;
    private String targetCareer;
    public static int studentCount = 0;

    public Student() {
        this.skills = new ArrayList();
        ++studentCount;
    }

    public Student(String var1, String var2, String var3, int var4, String var5, String var6, int var7, double var8) {
        super(var1, var2, var3, var4, var5);
        this.collegeName = var6;
        this.semester = var7;
        this.cgpa = var8;
        this.skills = new ArrayList();
        ++studentCount;
    }

    public void addSkill(Skill var1) {
        this.skills.add(var1);
    }

    public void removeSkill(String var1) {
        this.skills.removeIf((var1x) -> var1x.getSkillName().equalsIgnoreCase(var1));
    }

    public ArrayList<Skill> getSkills() {
        return this.skills;
    }

    public Skill getSkill(String var1) {
        for(Skill var3 : this.skills) {
            if (var3.getSkillName().equalsIgnoreCase(var1)) {
                return var3;
            }
        }

        return null;
    }

    public boolean hasSkill(String var1) {
        return this.getSkill(var1) != null;
    }

    public String getCollegeName() {
        return this.collegeName;
    }

    public int getSemester() {
        return this.semester;
    }

    public double getCgpa() {
        return this.cgpa;
    }

    public String getTargetCareer() {
        return this.targetCareer;
    }

    public void setCollegeName(String var1) {
        this.collegeName = var1;
    }

    public void setSemester(int var1) {
        this.semester = var1;
    }

    public void setCgpa(double var1) {
        this.cgpa = var1;
    }

    public void setTargetCareer(String var1) {
        this.targetCareer = var1;
    }

    public void displayDetails() {
        System.out.println("\n========== STUDENT DETAILS ==========");
        System.out.println("Student ID : " + this.studentId);
        System.out.println("Name       : " + this.name);
        System.out.println("Department : " + this.department);
        System.out.println("Age        : " + this.age);
        System.out.println("Gender     : " + this.gender);
        System.out.println("College    : " + this.collegeName);
        System.out.println("Semester   : " + this.semester);
        System.out.println("CGPA       : " + this.cgpa);
        System.out.println("Target     : " + this.targetCareer);
    }

    public void displayDetails(boolean var1) {
        this.displayDetails();
        if (var1) {
            for(Skill var3 : this.skills) {
                System.out.println(" - " + String.valueOf(var3));
            }
        }

    }

    public Student clone() {
        try {
            Student var1 = (Student)super.clone();
            var1.skills.clear();

            for(Skill var3 : this.skills) {
                var1.skills.add(new Skill(var3.getSkillId(), var3.getSkillName(), var3.getSkillScore()));
            }

            return var1;
        } catch (CloneNotSupportedException var4) {
            throw new AssertionError(var4);
        }
    }

    public List<Skill> skillView() {
        return new ArrayList(this.skills);
    }

    public String toString() {
        return this.name + " (" + this.studentId + ") - " + this.targetCareer;
    }
}
