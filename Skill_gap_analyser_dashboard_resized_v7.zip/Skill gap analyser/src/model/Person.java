package model;

public abstract class Person {
    protected String studentId;
    protected String name;
    protected String department;
    protected String gender;
    protected int age;

    public Person() {
    }

    public Person(String var1, String var2, String var3, int var4, String var5) {
        this.studentId = var1;
        this.name = var2;
        this.department = var3;
        this.age = var4;
        this.gender = var5;
    }

    public String getStudentId() {
        return this.studentId;
    }

    public String getName() {
        return this.name;
    }

    public String getDepartment() {
        return this.department;
    }

    public int getAge() {
        return this.age;
    }

    public String getGender() {
        return this.gender;
    }

    public void setStudentId(String var1) {
        this.studentId = var1;
    }

    public void setName(String var1) {
        this.name = var1;
    }

    public void setDepartment(String var1) {
        this.department = var1;
    }

    public void setAge(int var1) {
        this.age = var1;
    }

    public void setGender(String var1) {
        this.gender = var1;
    }

    public abstract void displayDetails();

    public void welcomeMessage() {
        System.out.println("\n==============================================\n        WELCOME TO SKILL GAP ANALYZER\n==============================================");
    }
}
