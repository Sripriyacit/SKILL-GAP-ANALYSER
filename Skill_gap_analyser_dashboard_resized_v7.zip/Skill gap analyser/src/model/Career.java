package model;

import java.util.LinkedHashMap;
import java.util.Map;

public class Career {
    private final String name;
    private final String description;
    private final LinkedHashMap<String, Integer> requiredSkills;
    private final String[] jobs;
    private final String[] courses;

    public Career(String var1, String var2, Map<String, Integer> var3, String[] var4, String[] var5) {
        this.name = var1;
        this.description = var2;
        this.requiredSkills = new LinkedHashMap(var3);
        this.jobs = var4;
        this.courses = var5;
    }

    public String getName() {
        return this.name;
    }

    public String getDescription() {
        return this.description;
    }

    public Map<String, Integer> getRequiredSkills() {
        return this.requiredSkills;
    }

    public String[] getJobs() {
        return this.jobs;
    }

    public String[] getCourses() {
        return this.courses;
    }
}
