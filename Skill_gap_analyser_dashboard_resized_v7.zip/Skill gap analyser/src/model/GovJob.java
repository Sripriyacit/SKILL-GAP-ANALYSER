package model;

/**
 * Represents a single government job opportunity along
 * with its eligibility criteria, used by the Government
 * Exams module.
 */
public class GovJob {

    private final String category;
    private final String name;
    private final String department;
    private final String qualification;
    private final String ageLimit;
    private final String selectionProcess;
    private final String description;

    public GovJob(String category, String name, String department,
                  String qualification, String ageLimit,
                  String selectionProcess, String description) {

        this.category = category;
        this.name = name;
        this.department = department;
        this.qualification = qualification;
        this.ageLimit = ageLimit;
        this.selectionProcess = selectionProcess;
        this.description = description;
    }

    public String getCategory() {
        return category;
    }

    public String getName() {
        return name;
    }

    public String getDepartment() {
        return department;
    }

    public String getQualification() {
        return qualification;
    }

    public String getAgeLimit() {
        return ageLimit;
    }

    public String getSelectionProcess() {
        return selectionProcess;
    }

    public String getDescription() {
        return description;
    }
}
