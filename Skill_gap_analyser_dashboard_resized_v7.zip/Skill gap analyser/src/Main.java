package main;

import database.SkillDatabase;
import exception.InvalidSkillException;
import java.io.PrintStream;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import model.Career;
import model.Skill;
import model.Student;
import model.UGStudent;
import service.CareerRecommendation;
import service.GapAnalyzer;
import service.SkillAnalyzer;
import util.FileManager;
import util.Logger;
import util.ReportGenerator;
import util.Validation;
import util.Statistics.SkillStatistics;

public class Main {
    private static final Scanner sc;
    private static final SkillAnalyzer skillAnalyzer;
    private static final GapAnalyzer gapAnalyzer;
    private static final CareerRecommendation recommendation;
    private static final ReportGenerator reportGenerator;
    private static final FileManager fileManager;

    public Main() {
    }

    public static void main(String[] var0) {
        Logger.getInstance().log("Application started");

        while(true) {
            printMenu();
            int var1 = readInt("Enter your choice: ");
            switch (var1) {
                case 1:
                    analyzeStudent();
                    break;
                case 2:
                    SkillDatabase.displayCareers();
                    break;
                case 3:
                    SkillDatabase.displaySkills();
                    break;
                case 4:
                    System.out.println("Students created in this session: " + Student.studentCount);
                    break;
                case 5:
                    Logger.getInstance().log("Application closed");
                    System.out.println("Thank you for using Skill Gap Analyzer!");
                    return;
                default:
                    System.out.println("Invalid choice. Please select 1-5.");
            }
        }
    }

    private static void printMenu() {
        System.out.println("\n==============================================");
        System.out.println("             SKILL GAP ANALYZER");
        System.out.println("==============================================");
        System.out.println("1. Analyze a Student");
        System.out.println("2. View Career Paths");
        System.out.println("3. View Available Skills");
        System.out.println("4. View Session Statistics");
        System.out.println("5. Exit");
    }

    private static void analyzeStudent() {
        System.out.println("\n---------- STUDENT REGISTRATION ----------");
        String var0 = readText("Student ID: ");
        String var1 = readText("Student Name: ");
        String var2 = readText("Department: ");

        int var3;
        for(var3 = readInt("Age (17-35): "); !Validation.validateAge(var3); var3 = readInt("Age: ")) {
            System.out.println("Age must be 17-35.");
        }

        String var4= readText("Gender (Male/Female/Other): ");

        while (!Validation.validateGender(var4)) {
            System.out.println(
                    "Invalid gender. Please enter Male, Female, or Other."
            );

            var4 = readText(
                    "Gender (Male/Female/Other): "
            );
        }
        String var5 = readText("College Name: ");

        int var6;
        for(var6 = readInt("Semester (1-8): "); !Validation.validateSemester(var6); var6 = readInt("Semester: ")) {
            System.out.println("Semester must be 1-8.");
        }

        double var7;
        for(var7 = readDouble("CGPA (0-10): "); !Validation.validateCGPA(var7); var7 = readDouble("CGPA: ")) {
            System.out.println("CGPA must be 0-10.");
        }

        SkillDatabase.displayCareers();
        int var9 = readInt("Select target career number: ");

        List var10;
        for(var10 = SkillDatabase.getCareers(); var9 < 1 || var9 > var10.size(); var9 = readInt("Select target career number: ")) {
            System.out.println("Invalid career choice.");
        }

        Career var11 = (Career)var10.get(var9 - 1);
        UGStudent var12 = new UGStudent(var0, var1, var2, var3, var4, var5, var6, var7, "Not specified");
        ((Student)var12).setTargetCareer(var11.getName());
        System.out.println("\nRequired skills for " + var11.getName() + ":");

        for(Map.Entry var14 : var11.getRequiredSkills().entrySet()) {
            PrintStream var10000 = System.out;
            String var10001 = (String)var14.getKey();
            var10000.println("- " + var10001 + " (target " + String.valueOf(var14.getValue()) + ")");
        }

        System.out.println("\nEnter your current skills. You can enter skills outside the target career too.");
        System.out.println("Type 'done' as the skill name when finished.");
        int var19 = 1;

        while(true) {
            String var20 = readText("Skill name: ");
            if (var20.equalsIgnoreCase("done")) {
                ((Student)var12).displayDetails();
                skillAnalyzer.analyze(var12);
                gapAnalyzer.printGapReport(var12, var11);
                recommendation.recommendJobs(var12);
                recommendation.recommendCourses(var12);
                recommendation.recommendSkills(var12);
                recommendation.recommendCareer(var12);
                SkillStatistics.calculate(var12);
                var20 = reportGenerator.generateReport(var12).toString();
                System.out.print("\nSave detailed report to file? (Y/N): ");
                String var22 = sc.nextLine().trim();
                if (var22.equalsIgnoreCase("y")) {
                    fileManager.saveReport(var20, "StudentReport_" + ((Student)var12).getStudentId() + ".txt");
                }

                System.out.println("\n========== ANALYSIS COMPLETE ==========");
                return;
            }

            String var15 = SkillDatabase.canonicalSkill(var20);
            if (var15 == null) {
                System.out.println("Unknown skill. Use View Available Skills to see valid names.");
            } else if (((Student)var12).hasSkill(var15)) {
                System.out.println("Skill already entered.");
            } else {
                int var16 = readInt("Proficiency (0-100): ");

                try {
                    Validation.validateSkillScore(var16);
                    int var10003 = var19++;
                    ((Student)var12).addSkill(new Skill("SK" + var10003, var15, var16));
                } catch (InvalidSkillException var18) {
                    System.out.println(var18.getMessage());
                }
            }
        }
    }

    private static String readText(String var0) {
        System.out.print(var0);
        return sc.nextLine().trim();
    }

    private static int readInt(String var0) {
        while(true) {
            try {
                System.out.print(var0);
                return Integer.parseInt(sc.nextLine().trim());
            } catch (Exception var2) {
                System.out.println("Please enter a valid integer.");
            }
        }
    }

    private static double readDouble(String var0) {
        while(true) {
            try {
                System.out.print(var0);
                return Double.parseDouble(sc.nextLine().trim());
            } catch (Exception var2) {
                System.out.println("Please enter a valid number.");
            }
        }
    }

    static {
        sc = new Scanner(System.in);
        skillAnalyzer = new SkillAnalyzer();
        gapAnalyzer = new GapAnalyzer();
        recommendation = new CareerRecommendation();
        reportGenerator = new ReportGenerator();
        fileManager = new FileManager();
    }
}
