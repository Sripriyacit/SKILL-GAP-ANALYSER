package web;

import util.JsonUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Full result of one assessment attempt: per-skill scores and
 * gaps, the overall fit, recommended job/path, an alternate
 * suggestion, a study plan and general tips.
 */
public class AssessmentResult {

    public static class SkillResult {

        public final String skill;
        public final int totalQuestions;
        public final int correctAnswers;
        public final double achieved;
        public final int required;
        public final int gap;
        public final String status;

        public SkillResult(String skill, int totalQuestions, int correctAnswers,
                            double achieved, int required) {

            this.skill = skill;
            this.totalQuestions = totalQuestions;
            this.correctAnswers = correctAnswers;
            this.achieved = achieved;
            this.required = required;
            this.gap = (int) Math.max(0, Math.round(required - achieved));
            this.status = achieved >= required ? "Achieved" : "Needs Improvement";
        }
    }

    public static class StudyItem {

        public final String skill;
        public final String resource;
        public final String tip;

        public StudyItem(String skill, String resource, String tip) {
            this.skill = skill;
            this.resource = resource;
            this.tip = tip;
        }
    }

    private final String module;
    private final String domainKey;
    private final String domainName;
    private final List<SkillResult> skillResults = new ArrayList<>();
    private double overallScore;
    private String fitLevel;
    private String recommendedRole;
    private String recommendedDescription;
    private String alternateRole;
    private String alternateDescription;
    private final List<StudyItem> studyPlan = new ArrayList<>();
    private final List<String> generalTips = new ArrayList<>();

    public AssessmentResult(String module, String domainKey, String domainName) {
        this.module = module;
        this.domainKey = domainKey;
        this.domainName = domainName;
    }

    public void addSkillResult(SkillResult result) {
        skillResults.add(result);
    }

    public void addStudyItem(StudyItem item) {
        studyPlan.add(item);
    }

    public void addGeneralTip(String tip) {
        generalTips.add(tip);
    }

    public void setOverallScore(double overallScore) {
        this.overallScore = overallScore;
    }

    public void setFitLevel(String fitLevel) {
        this.fitLevel = fitLevel;
    }

    public void setRecommendedRole(String recommendedRole) {
        this.recommendedRole = recommendedRole;
    }

    public void setRecommendedDescription(String recommendedDescription) {
        this.recommendedDescription = recommendedDescription;
    }

    public void setAlternateRole(String alternateRole) {
        this.alternateRole = alternateRole;
    }

    public void setAlternateDescription(String alternateDescription) {
        this.alternateDescription = alternateDescription;
    }

    public double getOverallScore() {
        return overallScore;
    }

    public String toJson() {

        StringBuilder json = new StringBuilder();

        json.append("{");
        json.append("\"module\":").append(JsonUtil.quote(module)).append(",");
        json.append("\"domainKey\":").append(JsonUtil.quote(domainKey)).append(",");
        json.append("\"domainName\":").append(JsonUtil.quote(domainName)).append(",");
        json.append("\"overallScore\":").append(round(overallScore)).append(",");
        json.append("\"fitLevel\":").append(JsonUtil.quote(fitLevel)).append(",");
        json.append("\"recommendedRole\":").append(JsonUtil.quote(recommendedRole)).append(",");
        json.append("\"recommendedDescription\":").append(JsonUtil.quote(recommendedDescription)).append(",");
        json.append("\"alternateRole\":").append(JsonUtil.quote(alternateRole)).append(",");
        json.append("\"alternateDescription\":").append(JsonUtil.quote(alternateDescription)).append(",");

        json.append("\"skillResults\":[");

        for (int i = 0; i < skillResults.size(); i++) {

            SkillResult r = skillResults.get(i);

            json.append("{");
            json.append("\"skill\":").append(JsonUtil.quote(r.skill)).append(",");
            json.append("\"totalQuestions\":").append(r.totalQuestions).append(",");
            json.append("\"correctAnswers\":").append(r.correctAnswers).append(",");
            json.append("\"achieved\":").append(round(r.achieved)).append(",");
            json.append("\"required\":").append(r.required).append(",");
            json.append("\"gap\":").append(r.gap).append(",");
            json.append("\"status\":").append(JsonUtil.quote(r.status));
            json.append("}");

            if (i < skillResults.size() - 1) {
                json.append(",");
            }
        }

        json.append("],");

        json.append("\"studyPlan\":[");

        for (int i = 0; i < studyPlan.size(); i++) {

            StudyItem item = studyPlan.get(i);

            json.append("{");
            json.append("\"skill\":").append(JsonUtil.quote(item.skill)).append(",");
            json.append("\"resource\":").append(JsonUtil.quote(item.resource)).append(",");
            json.append("\"tip\":").append(JsonUtil.quote(item.tip));
            json.append("}");

            if (i < studyPlan.size() - 1) {
                json.append(",");
            }
        }

        json.append("],");

        json.append("\"generalTips\":").append(JsonUtil.stringArray(generalTips));

        json.append("}");

        return json.toString();
    }

    private double round(double value) {
        return Math.round(value * 10.0) / 10.0;
    }
}
