/*
 * Shared helper for protected pages.
 * Checks /api/me and redirects to login.html if not logged in.
 * Also wires up any element with id="logoutBtn".
 */

async function requireLogin() {

    try {

        const response = await fetch("/api/me");
        const data = await response.json();

        if (!data.loggedIn) {
            window.location.href = "login.html";
            return null;
        }

        localStorage.setItem("fullName", data.fullName);

        const nameEls = document.querySelectorAll(".userFullName");

        nameEls.forEach(function (el) {
            el.textContent = data.fullName;
        });

        return data;

    } catch (err) {

        window.location.href = "login.html";
        return null;
    }
}

function wireLogout() {

    const logoutBtn = document.getElementById("logoutBtn");

    if (!logoutBtn) {
        return;
    }

    logoutBtn.addEventListener("click", async function (event) {

        event.preventDefault();

        try {
            await fetch("/api/logout", { method: "POST" });
        } catch (err) {
            // ignore network errors on logout
        }

        localStorage.clear();
        window.location.href = "index.html";
    });
}

document.addEventListener("DOMContentLoaded", function () {
    requireLogin();
    wireLogout();
});
