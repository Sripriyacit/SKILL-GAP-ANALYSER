package web;

import database.Domain;
import database.DomainCatalog;
import database.QuestionBank;
import database.SkillResourceCatalog;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Runs the actual skill gap analysis: scores the submitted
 * answers skill by skill, compares them against the domain's
 * required proficiency, and builds a full recommendation
 * (primary role, alternate role, study plan and tips).
 */
public final class AssessmentEngine {

    private AssessmentEngine() {
    }

    public static AssessmentResult evaluate(
            String module,
            String domainKey,
            List<String> testedSkills,
            Map<Integer, String> userAnswers) {

        Domain domain = DomainCatalog.findDomain(module, domainKey);

        if (domain == null) {
            return null;
        }

        List<String> skills = (testedSkills == null || testedSkills.isEmpty())
                ? domain.getSkills()
                : testedSkills;

        AssessmentResult result = new AssessmentResult(module, domainKey, domain.getName());

        double totalAchieved = 0;
        int skillCount = 0;

        for (String skill : skills) {

            List<Question> questions = QuestionBank.getQuestions(skill);

            int total = questions.size();
            int correct = 0;

            for (Question q : questions) {

                String userAnswer = userAnswers.get(q.getId());

                if (userAnswer != null
                        && userAnswer.equalsIgnoreCase(q.getCorrectAnswer())) {
                    correct++;
                }
            }

            double achieved = total == 0 ? 0 : ((double) correct / total) * 100.0;

            AssessmentResult.SkillResult skillResult =
                    new AssessmentResult.SkillResult(
                            skill, total, correct, achieved, domain.getRequiredScore());

            result.addSkillResult(skillResult);

            if (skillResult.gap > 0) {

                result.addStudyItem(new AssessmentResult.StudyItem(
                        skill,
                        SkillResourceCatalog.getResource(skill),
                        SkillResourceCatalog.getTip(skill)
                ));
            }

            totalAchieved += achieved;
            skillCount++;
        }

        double overallScore = skillCount == 0 ? 0 : totalAchieved / skillCount;

        result.setOverallScore(overallScore);

        buildRecommendation(result, domain, overallScore);

        for (String tip : generalTips(module)) {
            result.addGeneralTip(tip);
        }

        return result;
    }

    private static void buildRecommendation(
            AssessmentResult result, Domain domain, double overallScore) {

        if (overallScore >= 75) {

            result.setFitLevel("Strong Fit");
            result.setRecommendedRole(domain.getPrimaryRole());
            result.setRecommendedDescription(
                    "Your assessed skills strongly match the requirements for " + domain.getName()
                            + ". You are well positioned to pursue " + domain.getPrimaryRole() + ".");

            result.setAlternateRole(domain.getAlternateRole());
            result.setAlternateDescription(
                    "As a related backup option, you could also consider " + domain.getAlternateRole()
                            + " while you keep sharpening advanced skills.");

        } else if (overallScore >= 50) {

            result.setFitLevel("Moderate Fit");
            result.setRecommendedRole(domain.getAlternateRole());
            result.setRecommendedDescription(
                    "You have a reasonable foundation for " + domain.getName()
                            + ". " + domain.getAlternateRole()
                            + " is a good entry point while you close the remaining skill gaps for "
                            + domain.getPrimaryRole() + ".");

            result.setAlternateRole(domain.getPrimaryRole());
            result.setAlternateDescription(
                    "With focused study on your weaker skills, " + domain.getPrimaryRole()
                            + " becomes a realistic target in the near future.");

        } else {

            result.setFitLevel("Needs Foundation Building");
            result.setRecommendedRole("Skill-Building Phase for " + domain.getName());
            result.setRecommendedDescription(
                    "Your current proficiency is below the level typically expected for "
                            + domain.getName() + ". Focus on the fundamentals below before targeting "
                            + domain.getAlternateRole() + " or " + domain.getPrimaryRole() + ".");

            result.setAlternateRole(domain.getAlternateRole());
            result.setAlternateDescription(
                    "Once your fundamentals improve, " + domain.getAlternateRole()
                            + " is a realistic first target role.");
        }
    }

    private static List<String> generalTips(String module) {

        List<String> tips = new ArrayList<>();

        if (DomainCatalog.PLACEMENT.equals(module)) {

            tips.add("Build 2-3 real-world projects and host the code on GitHub.");
            tips.add("Practice mock interviews and communication skills every week.");
            tips.add("Keep your resume updated with clear, quantifiable achievements.");
            tips.add("Apply consistently and track every application in a spreadsheet.");

        } else if (DomainCatalog.STARTUP.equals(module)) {

            tips.add("Validate your idea with at least 10 potential customers before building.");
            tips.add("Track your finances from day one, even as a solo founder.");
            tips.add("Network with other founders and mentors through incubators and events.");
            tips.add("Explore Startup India / MSME registration for schemes and tax benefits.");

        } else if (DomainCatalog.HIGHER_STUDY.equals(module)) {

            tips.add("Create a fixed daily study timetable and stick to it.");
            tips.add("Solve previous years' question papers under timed conditions.");
            tips.add("Stay updated on exam notifications and application deadlines.");
            tips.add("Balance aptitude practice with core subject revision.");
        }

        return tips;
    }
}
