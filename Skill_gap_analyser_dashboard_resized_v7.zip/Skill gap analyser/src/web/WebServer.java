package web;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import database.Domain;
import database.DomainCatalog;
import database.GovJobCatalog;
import model.GovJob;
import model.User;
import util.JsonUtil;
import util.SessionManager;
import util.UserStore;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class WebServer {

    private static final int PORT = 8080;

    // Resolved once at startup - see locateFrontendRoot().
    private static final Path FRONTEND_ROOT = locateFrontendRoot();

    public static void main(String[] args) throws Exception {

        HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);

        server.createContext("/", WebServer::handleRequest);

        server.setExecutor(null);

        server.start();

        System.out.println("------------------------------------");
        System.out.println("Skill Gap Analyzer Web Server");
        System.out.println("------------------------------------");
        System.out.println("Working directory : " + Paths.get("").toAbsolutePath());
        System.out.println("Frontend folder    : " + (FRONTEND_ROOT == null
                ? "NOT FOUND - static pages will 404, see below"
                : FRONTEND_ROOT));

        if (FRONTEND_ROOT == null) {
            System.out.println("------------------------------------");
            System.out.println("Could not locate 'src/web/frontend'.");
            System.out.println("Run the server with its working directory set to the");
            System.out.println("project root (the folder that directly contains 'src').");
            System.out.println("In IntelliJ: Run > Edit Configurations > WebServer >");
            System.out.println("set 'Working directory' to the project folder.");
        }

        System.out.println("------------------------------------");
        System.out.println("Server started successfully.");
        System.out.println("Open: http://localhost:" + PORT);
        System.out.println("------------------------------------");
    }

    /**
     * Finds the "src/web/frontend" folder regardless of what directory
     * the server happens to be launched from, or how the project was
     * extracted/opened. It checks, in order:
     *  1. The current working directory itself.
     *  2. Its parent directories (server launched from a nested
     *     "out" / "bin" / module folder).
     *  3. Its subdirectories, a few levels deep (project extracted with
     *     an extra wrapper folder, e.g. "Downloads/Skill_gap_analyser (1)/
     *     Skill gap analyser/src/..." and IntelliJ opened the outer folder).
     *  4. The same three checks again, starting from wherever the
     *     compiled .class files are running from.
     */
    private static Path locateFrontendRoot() {

        Path cwd = Paths.get("").toAbsolutePath();

        Path found = searchUpward(cwd);

        if (found != null) {
            return found;
        }

        found = searchDownward(cwd, 5);

        if (found != null) {
            return found;
        }

        try {

            Path codeSource = Paths.get(
                    WebServer.class.getProtectionDomain()
                            .getCodeSource()
                            .getLocation()
                            .toURI()
            ).toAbsolutePath();

            Path start = Files.isDirectory(codeSource) ? codeSource : codeSource.getParent();

            found = searchUpward(start);

            if (found != null) {
                return found;
            }

            found = searchDownward(start, 5);

            if (found != null) {
                return found;
            }

        } catch (Exception ignored) {
            // fall through - FRONTEND_ROOT will stay null
        }

        return null;
    }

    private static Path searchUpward(Path start) {

        Path walker = start;

        for (int i = 0; i < 8 && walker != null; i++) {

            Path check = walker.resolve("src").resolve("web").resolve("frontend");

            if (isValidFrontendFolder(check)) {
                return check.normalize();
            }

            walker = walker.getParent();
        }

        return null;
    }

    private static Path searchDownward(Path start, int maxDepth) {

        if (start == null || !Files.isDirectory(start)) {
            return null;
        }

        try (var stream = Files.walk(start, maxDepth)) {

            return stream
                    .filter(Files::isDirectory)
                    .filter(p -> p.endsWith(Paths.get("src", "web", "frontend")))
                    .filter(WebServer::isValidFrontendFolder)
                    .findFirst()
                    .map(Path::normalize)
                    .orElse(null);

        } catch (IOException e) {
            return null;
        }
    }

    private static boolean isValidFrontendFolder(Path candidate) {
        return Files.isDirectory(candidate)
                && Files.exists(candidate.resolve("index.html"));
    }

    // =========================================================
    // ROUTING
    // =========================================================

    private static void handleRequest(HttpExchange exchange) throws IOException {

        String path = exchange.getRequestURI().getPath();

        try {

            if (path.equals("/api/register")) {
                handleRegister(exchange);
                return;
            }

            if (path.equals("/api/login")) {
                handleLogin(exchange);
                return;
            }

            if (path.equals("/api/logout")) {
                handleLogout(exchange);
                return;
            }

            if (path.equals("/api/me")) {
                handleMe(exchange);
                return;
            }

            if (path.equals("/api/domains")) {
                handleDomains(exchange);
                return;
            }

            if (path.equals("/api/questions")) {
                handleQuestions(exchange);
                return;
            }

            if (path.equals("/api/submit")) {
                handleSubmit(exchange);
                return;
            }

            if (path.equals("/api/govtjobs")) {
                handleGovtJobs(exchange);
                return;
            }

            serveStaticFile(exchange, path);

        } catch (Exception e) {

            sendJson(exchange, 500,
                    "{\"success\":false,\"message\":" + JsonUtil.quote(
                            "Server error: " + e.getMessage()) + "}");
        }
    }

    // =========================================================
    // AUTH
    // =========================================================

    private static void handleRegister(HttpExchange exchange) throws IOException {

        if (!isPost(exchange)) {
            sendJson(exchange, 405, "{\"success\":false,\"message\":\"POST method required\"}");
            return;
        }

        Map<String, String> data = parseFormData(readBody(exchange));

        UserStore.AuthResult result = UserStore.register(
                data.getOrDefault("fullName", ""),
                data.getOrDefault("email", ""),
                data.getOrDefault("username", ""),
                data.getOrDefault("password", ""),
                data.getOrDefault("confirmPassword", ""),
                data.getOrDefault("age", ""),
                data.getOrDefault("qualification", ""),
                data.getOrDefault("collegeName", ""),
                data.getOrDefault("department", ""),
                data.getOrDefault("semester", ""),
                data.getOrDefault("cgpa", "")
        );

        String json = "{"
                + "\"success\":" + result.success + ","
                + "\"message\":" + JsonUtil.quote(result.message)
                + "}";

        sendJson(exchange, 200, json);
    }

    private static void handleLogin(HttpExchange exchange) throws IOException {

        if (!isPost(exchange)) {
            sendJson(exchange, 405, "{\"success\":false,\"message\":\"POST method required\"}");
            return;
        }

        Map<String, String> data = parseFormData(readBody(exchange));

        UserStore.AuthResult result = UserStore.login(
                data.getOrDefault("username", ""),
                data.getOrDefault("password", "")
        );

        if (result.success) {

            String token = SessionManager.createSession(result.user.getUsername());

            exchange.getResponseHeaders().add(
                    "Set-Cookie",
                    SessionManager.COOKIE_NAME + "=" + token + "; Path=/; HttpOnly"
            );
        }

        String fullName = result.user == null ? "" : result.user.getFullName();

        String json = "{"
                + "\"success\":" + result.success + ","
                + "\"message\":" + JsonUtil.quote(result.message) + ","
                + "\"fullName\":" + JsonUtil.quote(fullName)
                + "}";

        sendJson(exchange, 200, json);
    }

    private static void handleLogout(HttpExchange exchange) throws IOException {

        String token = getCookie(exchange, SessionManager.COOKIE_NAME);

        SessionManager.invalidate(token);

        exchange.getResponseHeaders().add(
                "Set-Cookie",
                SessionManager.COOKIE_NAME + "=; Path=/; Max-Age=0"
        );

        sendJson(exchange, 200, "{\"success\":true}");
    }

    private static void handleMe(HttpExchange exchange) throws IOException {

        String token = getCookie(exchange, SessionManager.COOKIE_NAME);

        String username = SessionManager.getUsername(token);

        if (username == null) {
            sendJson(exchange, 200, "{\"loggedIn\":false}");
            return;
        }

        User user = UserStore.findByUsername(username);

        if (user == null) {
            sendJson(exchange, 200, "{\"loggedIn\":false}");
            return;
        }

        String json = "{"
                + "\"loggedIn\":true,"
                + "\"username\":" + JsonUtil.quote(user.getUsername()) + ","
                + "\"fullName\":" + JsonUtil.quote(user.getFullName())
                + "}";

        sendJson(exchange, 200, json);
    }

    // =========================================================
    // DOMAINS / QUESTIONS / SUBMIT
    // =========================================================

    private static void handleDomains(HttpExchange exchange) throws IOException {

        Map<String, String> query = getQueryParams(exchange);

        String module = query.getOrDefault("module", DomainCatalog.PLACEMENT);

        List<Domain> domains = DomainCatalog.getDomains(module);

        StringBuilder json = new StringBuilder("[");

        for (int i = 0; i < domains.size(); i++) {

            Domain d = domains.get(i);

            json.append("{");
            json.append("\"key\":").append(JsonUtil.quote(d.getKey())).append(",");
            json.append("\"name\":").append(JsonUtil.quote(d.getName())).append(",");
            json.append("\"description\":").append(JsonUtil.quote(d.getDescription())).append(",");
            json.append("\"skills\":").append(JsonUtil.stringArray(d.getSkills())).append(",");
            json.append("\"primaryRole\":").append(JsonUtil.quote(d.getPrimaryRole())).append(",");
            json.append("\"alternateRole\":").append(JsonUtil.quote(d.getAlternateRole()));
            json.append("}");

            if (i < domains.size() - 1) {
                json.append(",");
            }
        }

        json.append("]");

        sendJson(exchange, 200, json.toString());
    }

    private static void handleQuestions(HttpExchange exchange) throws IOException {

        Map<String, String> query = getQueryParams(exchange);

        String module = query.getOrDefault("module", DomainCatalog.PLACEMENT);
        String domainKey = query.getOrDefault("domain", "");
        String skillsParam = query.get("skills");

        Domain domain = DomainCatalog.findDomain(module, domainKey);

        if (domain == null) {
            sendJson(exchange, 404, "{\"success\":false,\"message\":\"Domain not found\"}");
            return;
        }

        List<String> skills = parseSkillsParam(skillsParam, domain);

        List<Question> questions = database.QuestionBank.getQuestionsForSkills(skills);

        StringBuilder json = new StringBuilder("[");

        for (int i = 0; i < questions.size(); i++) {

            Question q = questions.get(i);

            json.append("{");
            json.append("\"id\":").append(q.getId()).append(",");
            json.append("\"skill\":").append(JsonUtil.quote(q.getSkill())).append(",");
            json.append("\"question\":").append(JsonUtil.quote(q.getQuestion())).append(",");
            json.append("\"optionA\":").append(JsonUtil.quote(q.getOptionA())).append(",");
            json.append("\"optionB\":").append(JsonUtil.quote(q.getOptionB())).append(",");
            json.append("\"optionC\":").append(JsonUtil.quote(q.getOptionC())).append(",");
            json.append("\"optionD\":").append(JsonUtil.quote(q.getOptionD()));
            json.append("}");

            if (i < questions.size() - 1) {
                json.append(",");
            }
        }

        json.append("]");

        sendJson(exchange, 200, json.toString());
    }

    private static void handleSubmit(HttpExchange exchange) throws IOException {

        if (!isPost(exchange)) {
            sendJson(exchange, 405, "{\"success\":false,\"message\":\"POST method required\"}");
            return;
        }

        Map<String, String> data = parseFormData(readBody(exchange));

        String module = data.getOrDefault("module", DomainCatalog.PLACEMENT);
        String domainKey = data.getOrDefault("domain", "");
        String skillsParam = data.get("skills");
        String answersText = data.getOrDefault("answers", "");

        Domain domain = DomainCatalog.findDomain(module, domainKey);

        if (domain == null) {
            sendJson(exchange, 404, "{\"success\":false,\"message\":\"Domain not found\"}");
            return;
        }

        List<String> skills = parseSkillsParam(skillsParam, domain);

        Map<Integer, String> answers = new HashMap<>();

        if (!answersText.isEmpty()) {

            for (String pair : answersText.split(",")) {

                String[] parts = pair.split(":", 2);

                if (parts.length == 2) {

                    try {

                        int id = Integer.parseInt(parts[0].trim());
                        answers.put(id, parts[1].trim());

                    } catch (NumberFormatException ignored) {
                        // skip malformed entry
                    }
                }
            }
        }

        AssessmentResult result = AssessmentEngine.evaluate(module, domainKey, skills, answers);

        if (result == null) {
            sendJson(exchange, 404, "{\"success\":false,\"message\":\"Domain not found\"}");
            return;
        }

        sendJson(exchange, 200, result.toJson());
    }

    private static List<String> parseSkillsParam(String skillsParam, Domain domain) {

        if (skillsParam == null || skillsParam.trim().isEmpty()) {
            return domain.getSkills();
        }

        List<String> requested = Arrays.asList(skillsParam.split(","));

        List<String> valid = new ArrayList<>();

        for (String skill : requested) {

            String trimmed = skill.trim();

            if (domain.getSkills().contains(trimmed)) {
                valid.add(trimmed);
            }
        }

        return valid.isEmpty() ? domain.getSkills() : valid;
    }

    // =========================================================
    // GOVERNMENT JOBS
    // =========================================================

    private static void handleGovtJobs(HttpExchange exchange) throws IOException {

        Map<String, String> query = getQueryParams(exchange);

        String type = query.getOrDefault("type", GovJobCatalog.CENTRAL);

        List<GovJob> jobs = GovJobCatalog.getJobs(type);

        StringBuilder json = new StringBuilder("[");

        for (int i = 0; i < jobs.size(); i++) {

            GovJob job = jobs.get(i);

            json.append("{");
            json.append("\"name\":").append(JsonUtil.quote(job.getName())).append(",");
            json.append("\"department\":").append(JsonUtil.quote(job.getDepartment())).append(",");
            json.append("\"qualification\":").append(JsonUtil.quote(job.getQualification())).append(",");
            json.append("\"ageLimit\":").append(JsonUtil.quote(job.getAgeLimit())).append(",");
            json.append("\"selectionProcess\":").append(JsonUtil.quote(job.getSelectionProcess())).append(",");
            json.append("\"description\":").append(JsonUtil.quote(job.getDescription()));
            json.append("}");

            if (i < jobs.size() - 1) {
                json.append(",");
            }
        }

        json.append("]");

        sendJson(exchange, 200, json.toString());
    }

    // =========================================================
    // HELPERS
    // =========================================================

    private static boolean isPost(HttpExchange exchange) {
        return exchange.getRequestMethod().equalsIgnoreCase("POST");
    }

    private static String readBody(HttpExchange exchange) throws IOException {

        InputStream inputStream = exchange.getRequestBody();

        return new String(inputStream.readAllBytes(), StandardCharsets.UTF_8);
    }

    private static String getCookie(HttpExchange exchange, String name) {

        List<String> cookieHeaders = exchange.getRequestHeaders().get("Cookie");

        if (cookieHeaders == null) {
            return null;
        }

        for (String header : cookieHeaders) {

            String[] cookies = header.split(";");

            for (String cookie : cookies) {

                String[] parts = cookie.trim().split("=", 2);

                if (parts.length == 2 && parts[0].trim().equals(name)) {
                    return parts[1].trim();
                }
            }
        }

        return null;
    }

    private static Map<String, String> getQueryParams(HttpExchange exchange) {

        String query = exchange.getRequestURI().getQuery();

        return parseFormData(query == null ? "" : query);
    }

    private static Map<String, String> parseFormData(String body) {

        Map<String, String> data = new HashMap<>();

        if (body == null || body.isEmpty()) {
            return data;
        }

        String[] pairs = body.split("&");

        for (String pair : pairs) {

            String[] parts = pair.split("=", 2);

            if (parts.length == 2) {

                String key = URLDecoder.decode(parts[0], StandardCharsets.UTF_8);
                String value = URLDecoder.decode(parts[1], StandardCharsets.UTF_8);

                data.put(key, value);

            } else if (parts.length == 1 && !parts[0].isEmpty()) {

                String key = URLDecoder.decode(parts[0], StandardCharsets.UTF_8);
                data.put(key, "");
            }
        }

        return data;
    }

    private static void serveStaticFile(HttpExchange exchange, String requestPath) throws IOException {

        if (requestPath.equals("/")) {
            requestPath = "/index.html";
        }

        if (FRONTEND_ROOT == null) {

            sendResponse(exchange, 500, "text/plain",
                    "Could not locate the 'src/web/frontend' folder. "
                            + "Set the run configuration's working directory to the "
                            + "project root (the folder that contains 'src') and restart the server.");
            return;
        }

        Path filePath = FRONTEND_ROOT.resolve(requestPath.substring(1)).normalize();

        if (!filePath.startsWith(FRONTEND_ROOT)) {
            sendResponse(exchange, 403, "text/plain", "Access denied");
            return;
        }

        if (!Files.exists(filePath) || Files.isDirectory(filePath)) {
            sendResponse(exchange, 404, "text/plain", "Page not found");
            return;
        }

        byte[] content = Files.readAllBytes(filePath);

        String contentType = getContentType(filePath.toString());

        exchange.getResponseHeaders().set("Content-Type", contentType);

        exchange.sendResponseHeaders(200, content.length);

        OutputStream output = exchange.getResponseBody();

        output.write(content);
        output.close();
    }

    private static String getContentType(String fileName) {

        if (fileName.endsWith(".html")) {
            return "text/html; charset=UTF-8";
        }

        if (fileName.endsWith(".css")) {
            return "text/css; charset=UTF-8";
        }

        if (fileName.endsWith(".js")) {
            return "application/javascript; charset=UTF-8";
        }

        if (fileName.endsWith(".json")) {
            return "application/json; charset=UTF-8";
        }

        return "text/plain; charset=UTF-8";
    }

    private static void sendJson(HttpExchange exchange, int statusCode, String json) throws IOException {
        sendResponse(exchange, statusCode, "application/json; charset=UTF-8", json);
    }

    private static void sendResponse(HttpExchange exchange, int statusCode,
                                      String contentType, String response) throws IOException {

        byte[] bytes = response.getBytes(StandardCharsets.UTF_8);

        exchange.getResponseHeaders().set("Content-Type", contentType);

        exchange.sendResponseHeaders(statusCode, bytes.length);

        OutputStream output = exchange.getResponseBody();

        output.write(bytes);
        output.close();
    }
}
