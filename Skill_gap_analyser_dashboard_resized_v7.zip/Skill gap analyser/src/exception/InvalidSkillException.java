
package exception;

/**
 * Custom exception used when an invalid skill
 * proficiency score or skill-related value is entered.
 */
public class InvalidSkillException extends Exception {

    /**
     * Constructor for InvalidSkillException.
     *
     * @param message the error message
     */
    public InvalidSkillException(String message) {
        super(message);
    }
}

