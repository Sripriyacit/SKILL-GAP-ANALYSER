package database;

import java.util.Arrays;
import java.util.List;

/**
 * Represents one selectable path inside a module
 * (Placement, Startups or Higher Studies).
 *
 * Example: Placement -> "Web Development" domain
 * with skills HTML, CSS, JavaScript.
 */
public class Domain {

    private final String key;
    private final String name;
    private final String description;
    private final List<String> skills;
    private final String primaryRole;
    private final String alternateRole;
    private final int requiredScore;

    public Domain(String key, String name, String description,
                  String[] skills, String primaryRole,
                  String alternateRole, int requiredScore) {

        this.key = key;
        this.name = name;
        this.description = description;
        this.skills = Arrays.asList(skills);
        this.primaryRole = primaryRole;
        this.alternateRole = alternateRole;
        this.requiredScore = requiredScore;
    }

    public String getKey() {
        return key;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public List<String> getSkills() {
        return skills;
    }

    public String getPrimaryRole() {
        return primaryRole;
    }

    public String getAlternateRole() {
        return alternateRole;
    }

    public int getRequiredScore() {
        return requiredScore;
    }
}
