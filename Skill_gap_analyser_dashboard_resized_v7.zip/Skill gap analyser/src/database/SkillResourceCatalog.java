package database;

import java.util.HashMap;
import java.util.Map;

/**
 * Provides a short study resource suggestion and a practice
 * tip for every skill in the question bank. Used to build the
 * "recommendation to study the skill" section of a report.
 */
public final class SkillResourceCatalog {

    private SkillResourceCatalog() {
    }

    private static class Entry {
        String resource;
        String tip;

        Entry(String resource, String tip) {
            this.resource = resource;
            this.tip = tip;
        }
    }

    private static final Map<String, Entry> RESOURCES = new HashMap<>();

    private static void add(String skill, String resource, String tip) {
        RESOURCES.put(skill, new Entry(resource, tip));
    }

    static {

        add("Java", "Revise Core Java (OOP, Collections, Exceptions) using NPTEL / Coursera Java courses.",
                "Write a small program every day and re-implement common data structures from scratch.");

        add("DSA", "Practice Data Structures & Algorithms on GeeksforGeeks or LeetCode.",
                "Solve at least 2 problems a day, focusing on arrays, trees and recursion.");

        add("SQL", "Go through a structured SQL course (e.g. Mode Analytics SQL tutorial, W3Schools SQL).",
                "Practice writing joins, subqueries and aggregate queries on a sample database.");

        add("HTML", "Complete the freeCodeCamp Responsive Web Design certification.",
                "Rebuild a simple existing webpage from scratch using only HTML.");

        add("CSS", "Study Flexbox and Grid using the free \"Flexbox Froggy\" and \"Grid Garden\" games.",
                "Recreate the layout of a website you like using only CSS.");

        add("JavaScript", "Follow the JavaScript.info tutorial or a MERN-stack beginner course.",
                "Build a small interactive app (to-do list, calculator) using vanilla JavaScript.");

        add("Python", "Take a Python fundamentals course (e.g. Python for Everybody on Coursera).",
                "Automate a small daily task using a Python script.");

        add("Statistics", "Revise descriptive and inferential statistics through Khan Academy Statistics.",
                "Analyse a public dataset and summarise it using mean, median and standard deviation.");

        add("Machine Learning", "Complete an intro ML course (e.g. Andrew Ng's Machine Learning Specialization).",
                "Build a simple classification model using scikit-learn on a beginner dataset.");

        add("Networking", "Study computer networks fundamentals (OSI/TCP-IP model) via NPTEL.",
                "Use tools like ping and traceroute to explore how data travels across a network.");

        add("Linux", "Practice basic Linux commands using an online terminal (e.g. Linux Journey).",
                "Perform daily file, permission and process management tasks in a Linux terminal.");

        add("Security Fundamentals", "Take an intro cybersecurity course (e.g. Google Cybersecurity Certificate).",
                "Read about one real-world security incident every week and note the attack vector.");

        add("Cloud Computing", "Complete AWS/Azure/GCP fundamentals certification (free tier).",
                "Deploy a small static website or app on a free cloud tier account.");

        add("DevOps Tools", "Learn Git, Docker and CI/CD basics through hands-on labs (e.g. KodeKloud).",
                "Containerise one of your existing projects using Docker.");

        add("Product Thinking", "Study design thinking and MVP frameworks (e.g. IDEO / Y Combinator Startup School).",
                "Interview 5 potential users about a problem before designing any solution.");

        add("Programming Basics", "Complete a beginner programming course in Python or JavaScript.",
                "Practice writing small programs using loops, conditionals and functions daily.");

        add("Digital Marketing", "Take the free Google Digital Marketing & E-commerce Certificate.",
                "Run a small organic social media campaign and track its engagement metrics.");

        add("Financial Planning", "Study basic business finance (e.g. \"Finance for Non-Finance\" free courses).",
                "Build a simple monthly budget and cash-flow sheet for a hypothetical business.");

        add("Business Operations", "Read foundational business strategy material (e.g. Startup India learning modules).",
                "Map out the end-to-end process of running a small business on paper.");

        add("Communication & Pitching", "Practice pitching using the Y Combinator \"How to Pitch\" guide.",
                "Record yourself giving a 60-second pitch and review it for clarity.");

        add("Quantitative Aptitude", "Practice from RS Aggarwal Quantitative Aptitude or IndiaBix.",
                "Solve 10 timed aptitude questions daily and review mistakes.");

        add("Core Engineering Concepts", "Revise your core subject fundamentals using NPTEL / standard textbooks.",
                "Solve previous years' GATE questions from your core subject weekly.");

        add("Logical Reasoning", "Practice reasoning sets from RS Aggarwal Verbal & Non-Verbal Reasoning.",
                "Solve one full reasoning test under timed conditions every week.");

        add("Verbal Ability", "Build vocabulary and grammar using free GRE/CAT verbal ability material.",
                "Read one editorial article daily and note 5 new words.");

        add("Core Science Concepts", "Revise NCERT-level science fundamentals for your subject.",
                "Summarise one science topic in your own words every day.");

        add("English Proficiency", "Practice with free IELTS/TOEFL preparation material online.",
                "Practice speaking and writing in English for 15 minutes daily.");

        add("Mobile UI/UX", "Study mobile design guidelines (Material Design / Apple Human Interface Guidelines).",
                "Redesign one screen of an app you use daily and explain your design choices.");

        add("REST APIs", "Learn REST API basics through the free Postman API Fundamentals course.",
                "Use Postman to call a public API and inspect the JSON response.");

        add("Wireframing & Prototyping", "Learn wireframing and prototyping using Figma's free beginner tutorials.",
                "Wireframe a simple 3-screen app idea before writing any code.");

        add("Visual Design Principles", "Study visual design fundamentals (e.g. \"Refactoring UI\" concepts, free articles).",
                "Critique the design of an app you use daily using hierarchy, contrast and spacing.");

        add("Software Testing", "Take an intro software testing course (e.g. ISTQB Foundation basics, ministry of skill portals).",
                "Write 5 test cases for a simple login form, covering valid and invalid inputs.");
    }

    public static String getResource(String skill) {

        Entry entry = RESOURCES.get(skill);

        if (entry == null) {
            return "Practice " + skill + " using structured online tutorials and hands-on exercises.";
        }

        return entry.resource;
    }

    public static String getTip(String skill) {

        Entry entry = RESOURCES.get(skill);

        if (entry == null) {
            return "Dedicate at least 20-30 minutes a day to practising " + skill + ".";
        }

        return entry.tip;
    }
}
