package database;

import model.GovJob;

import java.util.ArrayList;
import java.util.List;

/**
 * Static catalog of central and state government job
 * opportunities along with their eligibility criteria.
 *
 * Note: age limits and processes are general guidelines and
 * may vary slightly by year and category (SC/ST/OBC/PwD get
 * relaxations) - candidates should always check the latest
 * official notification.
 */
public final class GovJobCatalog {

    private GovJobCatalog() {
    }

    public static final String CENTRAL = "central";
    public static final String STATE = "state";

    private static final List<GovJob> JOBS = new ArrayList<>();

    static {

        // ================= CENTRAL GOVERNMENT =================

        JOBS.add(new GovJob(CENTRAL,
                "UPSC Civil Services (IAS / IPS / IFS)",
                "Union Public Service Commission",
                "Bachelor's degree in any discipline",
                "21 - 32 years (relaxation for reserved categories)",
                "Preliminary Exam, Main Exam, Personality Test (Interview)",
                "India's top administrative and police services responsible for policy-making, district administration and law and order."
        ));

        JOBS.add(new GovJob(CENTRAL,
                "SSC CGL (Combined Graduate Level)",
                "Staff Selection Commission",
                "Bachelor's degree in any discipline",
                "18 - 32 years (varies by post)",
                "Tier I, Tier II Computer Based Exams, Document Verification",
                "Recruits graduates for group B and C posts such as Income Tax Inspector, Assistant Audit Officer and more."
        ));

        JOBS.add(new GovJob(CENTRAL,
                "SSC CHSL (Combined Higher Secondary Level)",
                "Staff Selection Commission",
                "10+2 (Higher Secondary) pass",
                "18 - 27 years",
                "Tier I, Tier II Exams, Skill/Typing Test",
                "Recruits for posts like Lower Division Clerk, Postal Assistant and Data Entry Operator."
        ));

        JOBS.add(new GovJob(CENTRAL,
                "IBPS PO (Bank Probationary Officer)",
                "Institute of Banking Personnel Selection",
                "Bachelor's degree in any discipline",
                "20 - 30 years",
                "Preliminary Exam, Main Exam, Interview",
                "Officer-level entry into public sector banks with fast-track growth into management roles."
        ));

        JOBS.add(new GovJob(CENTRAL,
                "RRB NTPC (Railway Recruitment Board)",
                "Ministry of Railways",
                "10+2 pass to Graduate, depending on post",
                "18 - 33 years (varies by post)",
                "Computer Based Test (Stages 1 & 2), Skill/Typing Test, Document Verification",
                "Non-technical popular category posts such as Station Master, Goods Guard and Clerk in Indian Railways."
        ));

        JOBS.add(new GovJob(CENTRAL,
                "UPSC Engineering Services Examination (ESE)",
                "Union Public Service Commission",
                "Engineering degree (Civil / Mechanical / Electrical / Electronics)",
                "21 - 30 years",
                "Preliminary Exam, Main Exam, Personality Test",
                "Recruits engineers into central government technical services such as Indian Railways and PWD."
        ));

        JOBS.add(new GovJob(CENTRAL,
                "Combined Defence Services (CDS)",
                "Union Public Service Commission / Ministry of Defence",
                "Bachelor's degree (branch depends on the academy applied for)",
                "19 - 25 years",
                "Written Exam, SSB Interview, Medical Test",
                "Commissions graduates as officers into the Indian Army, Navy and Air Force."
        ));

        JOBS.add(new GovJob(CENTRAL,
                "National Defence Academy (NDA)",
                "Union Public Service Commission / Ministry of Defence",
                "10+2 pass (Science stream required for Air Force/Navy)",
                "16.5 - 19.5 years",
                "Written Exam, SSB Interview, Medical Test",
                "Trains school-leavers to become officers in the Army, Navy and Air Force."
        ));

        JOBS.add(new GovJob(CENTRAL,
                "IBPS Clerk",
                "Institute of Banking Personnel Selection",
                "Bachelor's degree in any discipline",
                "20 - 28 years",
                "Preliminary Exam, Main Exam",
                "Entry-level clerical role handling customer transactions and records in public sector banks."
        ));

        JOBS.add(new GovJob(CENTRAL,
                "SBI PO (Probationary Officer)",
                "State Bank of India",
                "Bachelor's degree in any discipline",
                "21 - 30 years",
                "Preliminary Exam, Main Exam, Group Exercise & Interview",
                "Officer-level entry into India's largest public sector bank with fast-track growth."
        ));

        JOBS.add(new GovJob(CENTRAL,
                "Central Armed Police Forces (CAPF) - Assistant Commandant",
                "Staff Selection Commission / Ministry of Home Affairs",
                "Bachelor's degree in any discipline",
                "20 - 25 years",
                "Written Exam, Physical Efficiency Test, Interview, Medical Test",
                "Officer-level entry into forces such as CRPF, BSF, CISF and ITBP."
        ));

        JOBS.add(new GovJob(CENTRAL,
                "ISRO / DRDO Scientist / Engineer",
                "Indian Space Research Organisation / Defence Research and Development Organisation",
                "B.E./B.Tech in a relevant engineering discipline",
                "Up to 28 years (varies by post)",
                "Written Exam / GATE Score, Interview",
                "Research and engineering roles in India's premier space and defence research organisations."
        ));

        // ================= STATE GOVERNMENT =================

        JOBS.add(new GovJob(STATE,
                "State Public Service Commission - Group I / II Services",
                "State Public Service Commission",
                "Bachelor's degree in any discipline",
                "21 - 32 years (varies by state)",
                "Preliminary Exam, Main Exam, Interview",
                "State-level administrative posts such as Deputy Collector, Tahsildar and other Group A/B services."
        ));

        JOBS.add(new GovJob(STATE,
                "State Police Constable Recruitment",
                "State Police Department",
                "10+2 pass (varies by state)",
                "18 - 25 years",
                "Written Exam, Physical Efficiency Test, Medical Test",
                "Entry-level law enforcement role focused on maintaining public order and safety."
        ));

        JOBS.add(new GovJob(STATE,
                "State Police Sub-Inspector (SI)",
                "State Police Department",
                "Bachelor's degree in any discipline",
                "20 - 28 years",
                "Written Exam, Physical Efficiency Test, Interview, Medical Test",
                "Supervisory police role responsible for investigation and station-level administration."
        ));

        JOBS.add(new GovJob(STATE,
                "State TET / Teacher Recruitment Board (TRB)",
                "State Education Department",
                "Bachelor's degree + B.Ed (varies by grade taught)",
                "18 - 40 years (varies by state)",
                "Teacher Eligibility Test (TET), Written Exam, Interview",
                "Recruits teachers for government schools at primary, upper-primary and secondary levels."
        ));

        JOBS.add(new GovJob(STATE,
                "State Cooperative Bank Recruitment",
                "State Cooperative Bank",
                "Bachelor's degree in any discipline",
                "18 - 30 years",
                "Written Exam, Interview",
                "Banking and clerical roles within state-level cooperative banking institutions."
        ));

        JOBS.add(new GovJob(STATE,
                "State Forest Department (Forest Guard / Range Officer)",
                "State Forest Department",
                "10+2 pass for Forest Guard; Degree (Forestry/Science) for Range Officer",
                "18 - 30 years",
                "Written Exam, Physical Efficiency Test, Interview",
                "Roles focused on forest conservation, wildlife protection and enforcement of forest laws."
        ));

        JOBS.add(new GovJob(STATE,
                "State Municipal / Local Body Recruitment (Junior Assistant)",
                "State Municipal Corporation / Local Body",
                "10+2 pass or Bachelor's degree, depending on post",
                "18 - 35 years",
                "Written Exam, Document Verification",
                "Administrative and clerical roles supporting municipal services such as sanitation, revenue and records."
        ));

        JOBS.add(new GovJob(STATE,
                "State Agriculture / Veterinary Department Recruitment",
                "State Agriculture / Animal Husbandry Department",
                "Degree/Diploma in Agriculture, Veterinary Science or allied fields",
                "18 - 35 years",
                "Written Exam, Interview",
                "Technical field roles supporting farmers and livestock owners through extension services."
        ));

        JOBS.add(new GovJob(STATE,
                "State Electricity Board (Junior Engineer)",
                "State Electricity Board / Power Department",
                "Diploma/Degree in Electrical, Electronics or Mechanical Engineering",
                "18 - 32 years",
                "Written Exam, Interview, Document Verification",
                "Technical roles in power generation, distribution and maintenance for the state grid."
        ));

        JOBS.add(new GovJob(STATE,
                "State Excise / Prohibition Department",
                "State Excise Department",
                "10+2 pass or Bachelor's degree, depending on post",
                "18 - 30 years",
                "Written Exam, Physical Efficiency Test (for enforcement posts), Interview",
                "Roles enforcing state excise laws and regulating the sale of licensed goods."
        ));

        JOBS.add(new GovJob(STATE,
                "State Health Department (Staff Nurse / Health Inspector)",
                "State Health & Family Welfare Department",
                "Diploma/Degree in Nursing or Public Health, depending on post",
                "18 - 35 years",
                "Written Exam, Skill/Practical Test, Interview",
                "Frontline healthcare roles in government hospitals and primary health centres."
        ));

        JOBS.add(new GovJob(STATE,
                "State Transport Corporation (Driver / Conductor / Junior Assistant)",
                "State Road Transport Corporation",
                "10+2 pass; valid driving licence for driver posts",
                "18 - 30 years",
                "Written Exam, Driving Test (where applicable), Document Verification",
                "Operational and administrative roles supporting the state's public transport network."
        ));
    }

    public static List<GovJob> getJobs(String category) {

        List<GovJob> result = new ArrayList<>();

        for (GovJob job : JOBS) {

            if (job.getCategory().equalsIgnoreCase(category)) {
                result.add(job);
            }
        }

        return result;
    }
}
