package database;

import web.Question;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Holds the multiple-choice question bank used by the
 * assessment engine, organised by skill name.
 */
public final class QuestionBank {

    private QuestionBank() {
    }

    private static final Map<String, List<Question>> BANK = new LinkedHashMap<>();
    private static final Map<Integer, Question> BY_ID = new HashMap<>();
    private static int idCounter = 1;

    private static void add(String skill, String question,
                             String a, String b, String c, String d,
                             String correct) {

        List<Question> list = BANK.get(skill);

        if (list == null) {
            list = new ArrayList<>();
            BANK.put(skill, list);
        }

        Question q = new Question(idCounter++, skill, question, a, b, c, d, correct);

        list.add(q);
        BY_ID.put(q.getId(), q);
    }

    static {

        // ================= JAVA =================
        add("Java", "Which concept allows a subclass to provide a specific implementation of a method from its parent class?",
                "Encapsulation", "Overriding", "Overloading", "Abstraction", "B");
        add("Java", "Which keyword makes a variable accessible only within the class it is declared?",
                "public", "protected", "private", "static", "C");
        add("Java", "Which data structure does Java's ArrayList use internally?",
                "Linked List", "Array", "Hash Table", "Tree", "B");
        add("Java", "What is the default value of a boolean instance variable in Java?",
                "true", "false", "null", "0", "B");
        add("Java", "Which mechanism is used for handling runtime errors in Java?",
                "try-catch", "if-else", "for-loop", "switch-case", "A");

        // ================= DSA =================
        add("DSA", "Which data structure works on the LIFO principle?",
                "Queue", "Stack", "Array", "Linked List", "B");
        add("DSA", "What is the time complexity of binary search on a sorted array?",
                "O(n)", "O(n log n)", "O(log n)", "O(1)", "C");
        add("DSA", "Which tree traversal visits the root node between the left and right subtrees?",
                "Preorder", "Inorder", "Postorder", "Level order", "B");
        add("DSA", "Which sorting algorithm has the best average-case time complexity?",
                "Bubble Sort", "Selection Sort", "Merge Sort", "Insertion Sort", "C");
        add("DSA", "Which data structure is best suited for implementing a BFS traversal?",
                "Stack", "Queue", "Heap", "Trie", "B");

        // ================= SQL =================
        add("SQL", "Which SQL clause is used to filter grouped results?",
                "WHERE", "HAVING", "GROUP BY", "ORDER BY", "B");
        add("SQL", "Which SQL command removes a table's structure permanently?",
                "DELETE", "DROP", "TRUNCATE", "REMOVE", "B");
        add("SQL", "Which JOIN returns all rows from both tables, matched where possible?",
                "INNER JOIN", "LEFT JOIN", "FULL OUTER JOIN", "RIGHT JOIN", "C");
        add("SQL", "Which keyword removes duplicate rows from a result set?",
                "UNIQUE", "DISTINCT", "ONLY", "FILTER", "B");
        add("SQL", "Which constraint ensures a column can never store a NULL value?",
                "UNIQUE", "PRIMARY", "NOT NULL", "CHECK", "C");

        // ================= HTML =================
        add("HTML", "Which tag is used to define an unordered list?",
                "<ol>", "<ul>", "<li>", "<list>", "B");
        add("HTML", "Which attribute specifies alternate text for an image?",
                "title", "src", "alt", "desc", "C");
        add("HTML", "Which HTML5 tag is used to define navigation links?",
                "<nav>", "<menu>", "<section>", "<links>", "A");
        add("HTML", "Which tag is used to create a hyperlink?",
                "<link>", "<a>", "<href>", "<url>", "B");
        add("HTML", "Which input type is used to collect an email address?",
                "text", "mail", "email", "address", "C");

        // ================= CSS =================
        add("CSS", "Which property changes the text colour of an element?",
                "font-color", "text-color", "color", "foreground", "C");
        add("CSS", "Which CSS layout model is one-dimensional?",
                "Grid", "Flexbox", "Table", "Float", "B");
        add("CSS", "Which symbol represents a class selector in CSS?",
                "#", ".", "*", "@", "B");
        add("CSS", "Which property controls the space between an element's border and its content?",
                "margin", "padding", "spacing", "gap", "B");
        add("CSS", "Which property is used to make text bold?",
                "font-style", "text-weight", "font-weight", "text-bold", "C");

        // ================= JAVASCRIPT =================
        add("JavaScript", "Which keyword declares a block-scoped variable in JavaScript?",
                "var", "let", "global", "define", "B");
        add("JavaScript", "Which method converts a JSON string into a JavaScript object?",
                "JSON.stringify()", "JSON.parse()", "JSON.object()", "JSON.convert()", "B");
        add("JavaScript", "Which operator checks both value and type equality?",
                "==", "===", "=", "!=", "B");
        add("JavaScript", "Which built-in array method adds an element to the end of an array?",
                "push()", "pop()", "shift()", "unshift()", "A");
        add("JavaScript", "What does DOM stand for?",
                "Data Object Model", "Document Object Model", "Display Object Mode", "Document Order Model", "B");

        // ================= PYTHON =================
        add("Python", "Which keyword is used to define a function in Python?",
                "func", "def", "function", "lambda", "B");
        add("Python", "Which data type in Python is immutable?",
                "List", "Dictionary", "Tuple", "Set", "C");
        add("Python", "Which library is commonly used for numerical computing in Python?",
                "NumPy", "Pandas", "Matplotlib", "Flask", "A");
        add("Python", "What does the len() function return for a string?",
                "First character", "Number of characters", "Last character", "ASCII value", "B");
        add("Python", "Which symbol is used to write a comment in Python?",
                "//", "#", "/* */", "--", "B");

        // ================= STATISTICS =================
        add("Statistics", "Which measure represents the middle value of a sorted dataset?",
                "Mean", "Median", "Mode", "Range", "B");
        add("Statistics", "What does standard deviation measure?",
                "Central tendency", "Spread of data", "Frequency", "Correlation", "B");
        add("Statistics", "Which value occurs most frequently in a dataset?",
                "Mean", "Median", "Mode", "Variance", "C");
        add("Statistics", "A p-value less than 0.05 typically leads to which decision in hypothesis testing?",
                "Accept null hypothesis", "Reject null hypothesis", "Data is invalid", "No conclusion", "B");
        add("Statistics", "Which chart best shows the correlation between two numeric variables?",
                "Bar chart", "Pie chart", "Scatter plot", "Histogram", "C");

        // ================= MACHINE LEARNING =================
        add("Machine Learning", "Which type of learning uses labelled training data?",
                "Unsupervised", "Supervised", "Reinforcement", "Semi-random", "B");
        add("Machine Learning", "Which algorithm is commonly used for classification problems?",
                "Linear Regression", "K-Means", "Logistic Regression", "PCA", "C");
        add("Machine Learning", "What does \"overfitting\" mean in machine learning?",
                "Model performs well on new data", "Model performs well only on training data",
                "Model fails on training data", "Model has no parameters", "B");
        add("Machine Learning", "Which technique is used to reduce the number of input features?",
                "Clustering", "Dimensionality Reduction", "Classification", "Regression", "B");
        add("Machine Learning", "Which metric is commonly used to evaluate classification models?",
                "RMSE", "Accuracy", "MAE", "R-squared", "B");

        // ================= NETWORKING =================
        add("Networking", "What does IP stand for in networking?",
                "Internal Protocol", "Internet Protocol", "Interface Protocol", "Information Protocol", "B");
        add("Networking", "Which OSI layer is responsible for routing?",
                "Data Link", "Network", "Transport", "Session", "B");
        add("Networking", "Which protocol is used to securely browse websites?",
                "HTTP", "FTP", "HTTPS", "SMTP", "C");
        add("Networking", "What is the default port number for HTTP?",
                "21", "25", "80", "443", "C");
        add("Networking", "Which device connects multiple networks and routes data between them?",
                "Switch", "Hub", "Router", "Repeater", "C");

        // ================= LINUX =================
        add("Linux", "Which command lists files and directories in Linux?",
                "ls", "dir", "list", "show", "A");
        add("Linux", "Which command changes file permissions?",
                "chmod", "chperm", "permit", "access", "A");
        add("Linux", "Which command displays the current working directory?",
                "cwd", "pwd", "path", "dir", "B");
        add("Linux", "Which symbol redirects command output to a file, overwriting it?",
                "|", ">>", ">", "<", "C");
        add("Linux", "Which command is used to view currently running processes?",
                "ps", "proc", "run", "jobs", "A");

        // ================= SECURITY FUNDAMENTALS =================
        add("Security Fundamentals", "What does \"phishing\" refer to?",
                "A firewall technique", "A fraudulent attempt to obtain sensitive data",
                "A type of encryption", "A network protocol", "B");
        add("Security Fundamentals", "Which of these is an example of two-factor authentication?",
                "Password only", "Password + OTP", "Username only", "Security question only", "B");
        add("Security Fundamentals", "What is the primary purpose of a firewall?",
                "Speed up the network", "Filter and monitor network traffic", "Store passwords", "Compress data", "B");
        add("Security Fundamentals", "Which term describes malicious software designed to damage or disrupt systems?",
                "Firmware", "Malware", "Middleware", "Shareware", "B");
        add("Security Fundamentals", "What does \"encryption\" do to data?",
                "Deletes it", "Compresses it", "Converts it into an unreadable form for unauthorised users", "Duplicates it", "C");

        // ================= CLOUD COMPUTING =================
        add("Cloud Computing", "Which cloud service model provides virtual machines and storage?",
                "SaaS", "PaaS", "IaaS", "FaaS", "C");
        add("Cloud Computing", "What does \"scalability\" mean in cloud computing?",
                "Fixed capacity only", "Ability to increase or decrease resources on demand",
                "Only vertical growth", "Manual server addition only", "B");
        add("Cloud Computing", "Which of the following is a public cloud provider?",
                "AWS", "MySQL", "Linux", "Git", "A");
        add("Cloud Computing", "What is a \"virtual machine\"?",
                "A physical server", "A software-based emulation of a physical computer",
                "A type of database", "A network cable", "B");
        add("Cloud Computing", "Which cloud deployment model combines private and public clouds?",
                "Community cloud", "Hybrid cloud", "Public cloud", "Private cloud", "B");

        // ================= DEVOPS TOOLS =================
        add("DevOps Tools", "Which tool is widely used for version control?",
                "Jenkins", "Git", "Docker", "Ansible", "B");
        add("DevOps Tools", "Which tool is primarily used for containerisation?",
                "Docker", "Git", "Maven", "Slack", "A");
        add("DevOps Tools", "What is the primary purpose of Jenkins?",
                "Version control", "Continuous Integration / Continuous Deployment",
                "Container orchestration", "Cloud storage", "B");
        add("DevOps Tools", "Which tool is used for container orchestration at scale?",
                "Kubernetes", "GitHub", "Jira", "Trello", "A");
        add("DevOps Tools", "What does CI/CD stand for?",
                "Code Integration / Code Deployment", "Continuous Integration / Continuous Deployment",
                "Central Interface / Central Delivery", "Continuous Inspection / Continuous Debugging", "B");

        // ================= PRODUCT THINKING =================
        add("Product Thinking", "What is the first step in the design thinking process?",
                "Prototype", "Empathize", "Test", "Define", "B");
        add("Product Thinking", "What does MVP stand for in product development?",
                "Most Valuable Player", "Minimum Viable Product", "Maximum Value Proposition", "Market Validation Process", "B");
        add("Product Thinking", "Why is user feedback important in product development?",
                "It delays the launch", "It helps validate assumptions and improve the product",
                "It is not necessary", "It only matters after launch", "B");
        add("Product Thinking", "What is a \"problem statement\" used for?",
                "To define the solution first", "To clearly frame the user's core problem",
                "To set the price", "To hire employees", "B");
        add("Product Thinking", "Which term describes testing a product idea with minimal resources before full development?",
                "Scaling", "Validation / Prototyping", "Manufacturing", "Franchising", "B");

        // ================= PROGRAMMING BASICS =================
        add("Programming Basics", "What is a \"variable\" in programming?",
                "A fixed value that never changes", "A named storage location for data",
                "A type of loop", "A programming language", "B");
        add("Programming Basics", "Which control structure is used to repeat a block of code?",
                "Loop", "Variable", "Function", "Comment", "A");
        add("Programming Basics", "What is the main purpose of a function in programming?",
                "To store data permanently", "To reuse a block of logic",
                "To design the UI", "To connect to a database", "B");
        add("Programming Basics", "Which of these is a conditional statement?",
                "for", "while", "if-else", "print", "C");
        add("Programming Basics", "What does \"debugging\" mean?",
                "Writing new code", "Finding and fixing errors in code", "Deleting a program", "Compiling code", "B");

        // ================= DIGITAL MARKETING =================
        add("Digital Marketing", "What does SEO stand for?",
                "Search Engine Optimization", "Social Engagement Online",
                "Site Enhancement Operation", "Search Engagement Options", "A");
        add("Digital Marketing", "Which platform is primarily used for professional B2B marketing?",
                "Instagram", "LinkedIn", "TikTok", "Pinterest", "B");
        add("Digital Marketing", "What is \"conversion rate\" in digital marketing?",
                "Number of visitors to a site", "Percentage of users who complete a desired action",
                "Number of social media followers", "Total ad spend", "B");
        add("Digital Marketing", "What does CTR stand for?",
                "Click Through Rate", "Cost To Revenue", "Customer Trust Rating", "Content Type Rate", "A");
        add("Digital Marketing", "Which type of marketing uses influencers to promote products?",
                "Email marketing", "Influencer marketing", "Print marketing", "Cold calling", "B");

        // ================= FINANCIAL PLANNING =================
        add("Financial Planning", "What is a \"budget\" primarily used for?",
                "To track expenses and plan income allocation", "To increase taxes",
                "To hire employees", "To design products", "A");
        add("Financial Planning", "What does ROI stand for?",
                "Rate of Interest", "Return on Investment", "Risk of Inflation", "Revenue Over Income", "B");
        add("Financial Planning", "What is \"working capital\" in a business?",
                "Total company profit", "Difference between current assets and current liabilities",
                "Total number of employees", "Annual revenue", "B");
        add("Financial Planning", "Which financial statement shows a company's profit or loss over a period?",
                "Balance Sheet", "Income Statement", "Cash Flow Statement", "Tax Return", "B");
        add("Financial Planning", "What is \"bootstrapping\" in the context of a startup?",
                "Taking a large bank loan", "Funding a business with personal savings and revenue, without outside investment",
                "Going public via IPO", "Merging with another company", "B");

        // ================= BUSINESS OPERATIONS =================
        add("Business Operations", "What does \"supply chain management\" primarily deal with?",
                "Employee salaries", "Flow of goods and services from supplier to customer",
                "Marketing campaigns", "Legal contracts", "B");
        add("Business Operations", "What is a \"business model\"?",
                "A financial audit", "A plan describing how a company creates and delivers value to earn revenue",
                "A hiring plan", "A tax filing document", "B");
        add("Business Operations", "What does \"scaling a business\" mean?",
                "Reducing operations", "Growing the business efficiently to handle increased demand",
                "Shutting down a unit", "Changing the business name", "B");
        add("Business Operations", "Which term refers to the day-to-day tasks required to run a business?",
                "Strategy", "Operations", "Vision", "Branding", "B");
        add("Business Operations", "What is a \"stakeholder\"?",
                "Only the company's owner", "Anyone with an interest or investment in the business",
                "A government official", "A competitor", "B");

        // ================= COMMUNICATION & PITCHING =================
        add("Communication & Pitching", "What is the primary goal of an \"elevator pitch\"?",
                "To give a detailed financial report", "To quickly and clearly explain a business idea to grab interest",
                "To recite a resume", "To discuss company history", "B");
        add("Communication & Pitching", "What should a good pitch deck communicate first?",
                "Office location", "The problem being solved", "Employee names", "Company logo history", "B");
        add("Communication & Pitching", "Which skill is most critical when negotiating with investors?",
                "Aggression", "Active listening and clear communication", "Silence", "Avoiding questions", "B");
        add("Communication & Pitching", "What does \"storytelling\" in a pitch help achieve?",
                "Confuses the audience", "Makes the idea memorable and relatable",
                "Increases pitch length unnecessarily", "Replaces data entirely", "B");
        add("Communication & Pitching", "Why is knowing your audience important before a pitch?",
                "It isn't important", "It helps tailor the message to their interests and concerns",
                "To make the pitch longer", "To avoid answering questions", "B");

        // ================= QUANTITATIVE APTITUDE =================
        add("Quantitative Aptitude", "If a train travels 60 km in 1.5 hours, what is its speed?",
                "30 km/h", "40 km/h", "45 km/h", "90 km/h", "B");
        add("Quantitative Aptitude", "What is 15% of 200?",
                "20", "25", "30", "35", "C");
        add("Quantitative Aptitude", "What is the average of 10, 20 and 30?",
                "15", "20", "25", "30", "B");
        add("Quantitative Aptitude", "The ratio of two numbers is 3:4 and their sum is 63. Find the smaller number.",
                "27", "36", "21", "24", "A");
        add("Quantitative Aptitude", "A shopkeeper marks an item 20% above cost price and gives a 10% discount. What is his profit percentage?",
                "8%", "10%", "12%", "20%", "A");

        // ================= CORE ENGINEERING CONCEPTS =================
        add("Core Engineering Concepts", "What is the SI unit of force?",
                "Joule", "Newton", "Watt", "Pascal", "B");
        add("Core Engineering Concepts", "Ohm's Law relates voltage, current and which other quantity?",
                "Power", "Resistance", "Frequency", "Capacitance", "B");
        add("Core Engineering Concepts", "Which of these is a property of a good electrical conductor?",
                "High resistance", "Low resistance", "No free electrons", "High reactance", "B");
        add("Core Engineering Concepts", "What does CAD stand for in engineering?",
                "Computer Aided Design", "Central Automation Device", "Circuit Analysis Diagram", "Component Assembly Drawing", "A");
        add("Core Engineering Concepts", "Which gas law states pressure and volume are inversely proportional at constant temperature?",
                "Charles's Law", "Boyle's Law", "Avogadro's Law", "Gay-Lussac's Law", "B");

        // ================= LOGICAL REASONING =================
        add("Logical Reasoning", "Find the next number in the series: 2, 4, 8, 16, ?",
                "20", "24", "32", "18", "C");
        add("Logical Reasoning", "If all Cats are Animals, and all Animals need food, which conclusion is valid?",
                "All Cats need food", "All Animals are Cats", "No Cats need food", "Cannot be determined", "A");
        add("Logical Reasoning", "Which word does NOT belong with the others?",
                "Apple", "Banana", "Carrot", "Mango", "C");
        add("Logical Reasoning", "A is taller than B, and B is taller than C. Who is the shortest?",
                "A", "B", "C", "Cannot be determined", "C");
        add("Logical Reasoning", "Complete the analogy: Pen is to Write as Knife is to?",
                "Cook", "Cut", "Sharp", "Kitchen", "B");

        // ================= VERBAL ABILITY =================
        add("Verbal Ability", "Choose the correct synonym for \"Abundant\".",
                "Scarce", "Plentiful", "Empty", "Rare", "B");
        add("Verbal Ability", "Choose the correct antonym for \"Optimistic\".",
                "Hopeful", "Pessimistic", "Confident", "Cheerful", "B");
        add("Verbal Ability", "Identify the correctly spelled word.",
                "Acommodate", "Accommodate", "Acomodate", "Accomodate", "B");
        add("Verbal Ability", "Fill in the blank: \"She is __ honest person.\"",
                "a", "an", "the", "no article needed", "B");
        add("Verbal Ability", "Choose the correctly punctuated sentence.",
                "Its a great day.", "It's a great day.", "Its' a great day.", "It is' a great day.", "B");

        // ================= CORE SCIENCE CONCEPTS =================
        add("Core Science Concepts", "What is the chemical symbol for Sodium?",
                "So", "Na", "S", "Sd", "B");
        add("Core Science Concepts", "Which particle carries a negative charge in an atom?",
                "Proton", "Neutron", "Electron", "Nucleus", "C");
        add("Core Science Concepts", "What is the powerhouse of the cell?",
                "Nucleus", "Ribosome", "Mitochondria", "Golgi Body", "C");
        add("Core Science Concepts", "Which law states that energy cannot be created or destroyed?",
                "Newton's First Law", "Law of Conservation of Energy", "Law of Gravitation", "Boyle's Law", "B");
        add("Core Science Concepts", "What is the pH value of a neutral solution?",
                "0", "7", "14", "10", "B");

        // ================= ENGLISH PROFICIENCY =================
        add("English Proficiency", "Choose the correct form: \"He __ to the market yesterday.\"",
                "go", "goes", "went", "going", "C");
        add("English Proficiency", "Which sentence is grammatically correct?",
                "She don't like tea.", "She doesn't likes tea.", "She doesn't like tea.", "She not like tea.", "C");
        add("English Proficiency", "Choose the correct plural form of \"Child\".",
                "Childs", "Childes", "Children", "Childrens", "C");
        add("English Proficiency", "Identify the noun in the sentence: \"The quick brown fox jumps.\"",
                "Quick", "Brown", "Fox", "Jumps", "C");
        add("English Proficiency", "Choose the correct preposition: \"She is good __ mathematics.\"",
                "in", "at", "on", "with", "B");

        // ================= MOBILE UI/UX =================
        add("Mobile UI/UX", "What is the primary goal of mobile-first design?",
                "Design for desktop first, then shrink it", "Design for the smallest/mobile screen first and scale up",
                "Ignore screen size entirely", "Only use native apps, never web", "B");
        add("Mobile UI/UX", "Which touch target size is generally recommended as a minimum for mobile buttons?",
                "10x10 px", "24x24 px", "44x44 px", "100x100 px", "C");
        add("Mobile UI/UX", "What does \"responsive design\" allow an app or website to do?",
                "Load faster only on Wi-Fi", "Adapt its layout to different screen sizes",
                "Work only offline", "Use a fixed pixel layout everywhere", "B");
        add("Mobile UI/UX", "Which navigation pattern is most common at the bottom of mobile apps?",
                "Breadcrumbs", "Bottom navigation bar", "Mega menu", "Sidebar only", "B");
        add("Mobile UI/UX", "Why is \"thumb zone\" important in mobile UI design?",
                "It decides the app's color scheme", "It identifies areas users can comfortably reach with their thumb",
                "It controls battery usage", "It is only relevant for tablets", "B");

        // ================= REST APIS =================
        add("REST APIs", "Which HTTP method is typically used to retrieve data from a REST API?",
                "POST", "GET", "DELETE", "PUT", "B");
        add("REST APIs", "What does REST stand for?",
                "Remote End State Transfer", "Representational State Transfer",
                "Rapid Endpoint Service Transfer", "Reliable Endpoint State Transaction", "B");
        add("REST APIs", "Which HTTP status code indicates a successful request?",
                "404", "500", "200", "301", "C");
        add("REST APIs", "Which data format is most commonly used in modern REST API responses?",
                "XML only", "JSON", "CSV", "Plain text only", "B");
        add("REST APIs", "Which HTTP method is typically used to update an existing resource?",
                "GET", "PUT", "OPTIONS", "HEAD", "B");

        // ================= WIREFRAMING & PROTOTYPING =================
        add("Wireframing & Prototyping", "What is the main purpose of a wireframe?",
                "To finalize brand colors", "To outline the layout and structure of a screen before visual design",
                "To write backend code", "To test server performance", "B");
        add("Wireframing & Prototyping", "Which fidelity level is typically used earliest in the design process?",
                "High-fidelity prototype", "Low-fidelity wireframe", "Final production build", "Marketing mockup", "B");
        add("Wireframing & Prototyping", "What is a \"clickable prototype\" mainly used for?",
                "Writing documentation", "Simulating user interaction before development", "Hosting the live app",
                "Storing user data", "B");
        add("Wireframing & Prototyping", "Which of these is a common prototyping tool?",
                "Figma", "Excel", "Notepad", "Photoshop only", "A");
        add("Wireframing & Prototyping", "What is the benefit of user testing a prototype before development?",
                "It guarantees zero bugs", "It helps catch usability issues early and cheaply",
                "It replaces the need for design entirely", "It is only useful after launch", "B");

        // ================= VISUAL DESIGN PRINCIPLES =================
        add("Visual Design Principles", "What does \"visual hierarchy\" help achieve in a design?",
                "It guides the user's attention to the most important elements first",
                "It hides important information", "It only affects font size", "It is unrelated to usability", "A");
        add("Visual Design Principles", "Which principle refers to grouping related elements close together?",
                "Contrast", "Alignment", "Proximity", "Repetition", "C");
        add("Visual Design Principles", "Why is consistent use of color and typography important in design?",
                "It has no real impact", "It builds a recognizable and professional visual identity",
                "It only matters for print media", "It slows down development", "B");
        add("Visual Design Principles", "What is the purpose of white space (negative space) in a layout?",
                "To reduce visual clutter and improve readability", "To fill unused space with ads",
                "To always be avoided", "To reduce file size", "A");
        add("Visual Design Principles", "Which color combination is generally used to ensure good readability?",
                "Low contrast colors", "High contrast between text and background", "Random colors",
                "Same color for text and background", "B");

        // ================= SOFTWARE TESTING =================
        add("Software Testing", "What is the main goal of software testing?",
                "To write more code", "To find defects and verify the software meets requirements",
                "To design the UI", "To deploy the application", "B");
        add("Software Testing", "Which testing type checks if individual functions/methods work correctly in isolation?",
                "System Testing", "Unit Testing", "Acceptance Testing", "Load Testing", "B");
        add("Software Testing", "What is \"regression testing\" used for?",
                "Testing only new features", "Ensuring existing functionality still works after changes",
                "Testing hardware performance", "Testing only the database", "B");
        add("Software Testing", "Which of these best describes \"black-box testing\"?",
                "Testing based on internal code structure", "Testing based on inputs and outputs without seeing internal code",
                "Testing only the database schema", "Testing only performance", "B");
        add("Software Testing", "What is a \"test case\"?",
                "A physical box used to store test devices",
                "A documented set of steps, inputs and expected results to verify a feature",
                "A type of programming language", "A server configuration file", "B");
    }

    public static List<Question> getQuestions(String skill) {

        List<Question> list = BANK.get(skill);

        return list == null ? new ArrayList<>() : list;
    }

    public static List<Question> getQuestionsForSkills(List<String> skills) {

        List<Question> result = new ArrayList<>();

        for (String skill : skills) {
            result.addAll(getQuestions(skill));
        }

        return result;
    }

    public static Question findById(int id) {
        return BY_ID.get(id);
    }
}
