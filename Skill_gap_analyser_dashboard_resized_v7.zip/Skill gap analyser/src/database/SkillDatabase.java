
package database;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import model.Career;

        public final class SkillDatabase {

            // =========================================================
            // AVAILABLE SKILLS
            // =========================================================

            private static final List<String> SKILLS = Arrays.asList(

                    // =================================================
                    // PROGRAMMING LANGUAGES
                    // =================================================

                    "Java",
                    "Python",
                    "C",
                    "C++",
                    "C#",
                    "JavaScript",
                    "TypeScript",
                    "Kotlin",
                    "Dart",
                    "Go",
                    "PHP",
                    "Rust",

                    // =================================================
                    // WEB DEVELOPMENT
                    // =================================================

                    "HTML",
                    "CSS",
                    "JavaScript",
                    "React",
                    "Angular",
                    "Vue.js",
                    "Node.js",
                    "Express.js",
                    "REST API",
                    "API Development",

                    // =================================================
                    // JAVA TECHNOLOGIES
                    // =================================================

                    "OOP",
                    "DSA",
                    "JDBC",
                    "Spring Boot",
                    "Hibernate",
                    "Maven",

                    // =================================================
                    // DATABASE
                    // =================================================

                    "SQL",
                    "DBMS",
                    "MySQL",
                    "PostgreSQL",
                    "Oracle",
                    "MongoDB",
                    "Database Design",
                    "Database Security",

                    // =================================================
                    // CORE COMPUTER SCIENCE
                    // =================================================

                    "Operating System",
                    "Computer Networks",
                    "Algorithms",
                    "Problem Solving",
                    "Data Structures",

                    // =================================================
                    // DATA SCIENCE
                    // =================================================

                    "Statistics",
                    "Probability",
                    "Pandas",
                    "NumPy",
                    "Matplotlib",
                    "Seaborn",
                    "Data Visualization",
                    "Excel",
                    "Power BI",
                    "Tableau",

                    // =================================================
                    // ARTIFICIAL INTELLIGENCE
                    // =================================================

                    "Artificial Intelligence",
                    "Machine Learning",
                    "Deep Learning",
                    "Natural Language Processing",
                    "Computer Vision",
                    "TensorFlow",
                    "PyTorch",
                    "Scikit-learn",
                    "Large Language Models",
                    "Prompt Engineering",

                    // =================================================
                    // CLOUD COMPUTING
                    // =================================================

                    "AWS",
                    "Azure",
                    "Google Cloud",
                    "Cloud Computing",
                    "Cloud Architecture",
                    "Cloud Security",

                    // =================================================
                    // DEVOPS
                    // =================================================

                    "Linux",
                    "Git",
                    "GitHub",
                    "Docker",
                    "Kubernetes",
                    "Jenkins",
                    "CI/CD",
                    "Terraform",
                    "Shell Scripting",
                    "Monitoring",

                    // =================================================
                    // CYBERSECURITY
                    // =================================================

                    "Cybersecurity",
                    "Ethical Hacking",
                    "Penetration Testing",
                    "Cryptography",
                    "Network Security",
                    "Web Security",
                    "SIEM",
                    "Incident Response",

                    // =================================================
                    // SOFTWARE TESTING
                    // =================================================

                    "Manual Testing",
                    "Selenium",
                    "API Testing",
                    "Postman",
                    "Performance Testing",
                    "JMeter",
                    "TestNG",
                    "Test Case Design",
                    "Bug Tracking",

                    // =================================================
                    // MOBILE DEVELOPMENT
                    // =================================================

                    "Android Studio",
                    "Flutter",
                    "Firebase",
                    "SQLite",

                    // =================================================
                    // UI/UX DESIGN
                    // =================================================

                    "UI Design",
                    "UX Design",
                    "Figma",
                    "Adobe XD",
                    "Wireframing",
                    "Prototyping",
                    "User Research",

                    // =================================================
                    // GAME DEVELOPMENT
                    // =================================================

                    "Unity",
                    "Unreal Engine",
                    "Game Physics",
                    "3D Mathematics",

                    // =================================================
                    // BLOCKCHAIN
                    // =================================================

                    "Blockchain",
                    "Solidity",
                    "Ethereum",
                    "Smart Contracts",
                    "Web3",

                    // =================================================
                    // IOT AND EMBEDDED
                    // =================================================

                    "IoT",
                    "Arduino",
                    "Raspberry Pi",
                    "MQTT",
                    "Embedded Systems",
                    "Microcontrollers",
                    "Electronics",

                    // =================================================
                    // ROBOTICS
                    // =================================================

                    "Robotics",
                    "ROS",
                    "Control Systems",

                    // =================================================
                    // NETWORKING
                    // =================================================

                    "TCP/IP",
                    "Routing",
                    "Switching",
                    "DNS",
                    "DHCP",
                    "Cisco",

                    // =================================================
                    // BUSINESS
                    // =================================================

                    "Business Analysis",
                    "Requirement Analysis",
                    "Business Strategy",
                    "Product Management",
                    "Market Research",

                    // =================================================
                    // PROJECT MANAGEMENT
                    // =================================================

                    "Project Management",
                    "Agile",
                    "Scrum",
                    "Leadership",
                    "Team Management",
                    "Risk Management",
                    "Time Management",

                    // =================================================
                    // DIGITAL MARKETING
                    // =================================================

                    "Digital Marketing",
                    "SEO",
                    "SEM",
                    "Content Marketing",
                    "Social Media Marketing",
                    "Google Analytics",
                    "Email Marketing",

                    // =================================================
                    // FINANCE
                    // =================================================

                    "Financial Analysis",
                    "Financial Technology",
                    "Financial Modeling",

                    // =================================================
                    // PROFESSIONAL SKILLS
                    // =================================================

                    "Communication",
                    "Documentation",
                    "Presentation",
                    "Critical Thinking",
                    "Creativity"
            );


            // =========================================================
            // CAREER DATABASE
            // =========================================================

            private static final Map<String, Career> CAREERS =
                    new LinkedHashMap<>();


            // =========================================================
            // PRIVATE CONSTRUCTOR
            // =========================================================

            private SkillDatabase() {
            }


            // =========================================================
            // CREATE CAREER
            // =========================================================

            private static Career career(
                    String name,
                    String description,
                    Map<String, Integer> requiredSkills,
                    String[] jobRoles,
                    String[] courses
            ) {

                return new Career(
                        name,
                        description,
                        requiredSkills,
                        jobRoles,
                        courses
                );
            }


            // =========================================================
            // CREATE REQUIRED SKILLS
            // =========================================================

            private static Map<String, Integer> req(
                    Object... values
            ) {

                Map<String, Integer> requiredSkills =
                        new LinkedHashMap<>();

                for (int i = 0; i < values.length; i += 2) {

                    String skillName =
                            (String) values[i];

                    Integer requiredLevel =
                            (Integer) values[i + 1];

                    requiredSkills.put(
                            skillName,
                            requiredLevel
                    );
                }

                return requiredSkills;
            }


            // =========================================================
            // GET ALL SKILLS
            // =========================================================

            public static List<String> getSkillList() {

                return new ArrayList<>(SKILLS);
            }


            // =========================================================
            // CHECK SKILL
            // =========================================================

            public static boolean skillExists(
                    String skillName
            ) {

                if (skillName == null) {
                    return false;
                }

                for (String skill : SKILLS) {

                    if (skill.equalsIgnoreCase(skillName)) {
                        return true;
                    }
                }

                return false;
            }


            // =========================================================
            // GET CANONICAL SKILL
            // =========================================================

            public static String canonicalSkill(
                    String skillName
            ) {

                if (skillName == null) {
                    return null;
                }

                for (String skill : SKILLS) {

                    if (skill.equalsIgnoreCase(skillName)) {
                        return skill;
                    }
                }

                return null;
            }


            // =========================================================
            // GET ALL CAREERS
            // =========================================================

            public static List<Career> getCareers() {

                return new ArrayList<>(
                        CAREERS.values()
                );
            }


            // =========================================================
            // GET CAREER
            // =========================================================

            public static Career getCareer(
                    String careerName
            ) {

                if (careerName == null) {
                    return null;
                }

                for (Career career : CAREERS.values()) {

                    if (career.getName()
                            .equalsIgnoreCase(careerName)) {

                        return career;
                    }
                }

                return null;
            }


            // =========================================================
            // DISPLAY SKILLS
            // =========================================================

            public static void displaySkills() {

                System.out.println();
                System.out.println(
                        "========== AVAILABLE SKILLS =========="
                );

                for (int i = 0; i < SKILLS.size(); i++) {

                    System.out.printf(
                            "%3d. %s%n",
                            i + 1,
                            SKILLS.get(i)
                    );
                }
            }


            // =========================================================
            // DISPLAY CAREERS
            // =========================================================

            public static void displayCareers() {

                System.out.println();
                System.out.println(
                        "========== CAREER PATHS =========="
                );

                int number = 1;

                for (Career career : CAREERS.values()) {

                    System.out.printf(
                            "%2d. %-30s - %s%n",
                            number,
                            career.getName(),
                            career.getDescription()
                    );

                    number++;
                }
            }


            // =========================================================
            // CAREER DATABASE
            // 25 DOMAINS / 50 CAREER PATHS
            // =========================================================

            static {

                // =====================================================
                // DOMAIN 1 - SOFTWARE DEVELOPMENT
                // =====================================================

                CAREERS.put(
                        "Java Developer",
                        career(
                                "Java Developer",
                                "Build backend and enterprise applications using Java.",
                                req(
                                        "Java", 85,
                                        "OOP", 80,
                                        "DSA", 75,
                                        "SQL", 70,
                                        "JDBC", 65,
                                        "Spring Boot", 70,
                                        "REST API", 70,
                                        "Git", 60
                                ),
                                new String[]{
                                        "Junior Java Developer",
                                        "Java Developer",
                                        "Backend Developer",
                                        "Enterprise Java Developer"
                                },
                                new String[]{
                                        "Core Java",
                                        "Advanced OOP",
                                        "DSA with Java",
                                        "Spring Boot",
                                        "REST API Development"
                                }
                        )
                );


                CAREERS.put(
                        "Python Developer",
                        career(
                                "Python Developer",
                                "Develop software, automation tools and backend services using Python.",
                                req(
                                        "Python", 85,
                                        "OOP", 70,
                                        "DSA", 60,
                                        "SQL", 65,
                                        "Git", 60,
                                        "REST API", 65,
                                        "Problem Solving", 75
                                ),
                                new String[]{
                                        "Python Developer",
                                        "Backend Developer",
                                        "Automation Developer"
                                },
                                new String[]{
                                        "Advanced Python",
                                        "Python OOP",
                                        "Python DSA",
                                        "Django and Flask",
                                        "REST API"
                                }
                        )
                );


                // =====================================================
                // DOMAIN 2 - WEB DEVELOPMENT
                // =====================================================

                CAREERS.put(
                        "Frontend Developer",
                        career(
                                "Frontend Developer",
                                "Create responsive and interactive user interfaces for web applications.",
                                req(
                                        "HTML", 90,
                                        "CSS", 85,
                                        "JavaScript", 85,
                                        "React", 75,
                                        "Git", 65,
                                        "REST API", 60
                                ),
                                new String[]{
                                        "Frontend Developer",
                                        "UI Developer",
                                        "React Developer"
                                },
                                new String[]{
                                        "HTML and CSS",
                                        "Modern JavaScript",
                                        "React",
                                        "Responsive Web Design",
                                        "Git and GitHub"
                                }
                        )
                );


                CAREERS.put(
                        "Full Stack Developer",
                        career(
                                "Full Stack Developer",
                                "Develop complete frontend and backend web applications.",
                                req(
                                        "HTML", 80,
                                        "CSS", 80,
                                        "JavaScript", 85,
                                        "React", 75,
                                        "Node.js", 75,
                                        "SQL", 70,
                                        "REST API", 80,
                                        "Git", 70
                                ),
                                new String[]{
                                        "Full Stack Developer",
                                        "Web Application Developer",
                                        "Software Developer"
                                },
                                new String[]{
                                        "Frontend Development",
                                        "React",
                                        "Node.js",
                                        "Database Development",
                                        "REST API"
                                }
                        )
                );


                // =====================================================
                // DOMAIN 3 - MOBILE DEVELOPMENT
                // =====================================================

                CAREERS.put(
                        "Android Developer",
                        career(
                                "Android Developer",
                                "Build mobile applications for Android devices.",
                                req(
                                        "Java", 70,
                                        "Kotlin", 85,
                                        "Android Studio", 85,
                                        "OOP", 75,
                                        "REST API", 70,
                                        "SQLite", 65,
                                        "Firebase", 65,
                                        "Git", 60
                                ),
                                new String[]{
                                        "Android Developer",
                                        "Mobile Application Developer",
                                        "Android Engineer"
                                },
                                new String[]{
                                        "Kotlin",
                                        "Android Studio",
                                        "Android UI Development",
                                        "Firebase",
                                        "REST API"
                                }
                        )
                );


                CAREERS.put(
                        "Flutter Developer",
                        career(
                                "Flutter Developer",
                                "Develop cross-platform mobile applications using Flutter.",
                                req(
                                        "Dart", 85,
                                        "Flutter", 90,
                                        "OOP", 70,
                                        "REST API", 70,
                                        "Firebase", 75,
                                        "Git", 60
                                ),
                                new String[]{
                                        "Flutter Developer",
                                        "Mobile Developer",
                                        "Cross Platform Developer"
                                },
                                new String[]{
                                        "Dart Programming",
                                        "Flutter Development",
                                        "Firebase",
                                        "Mobile UI Design",
                                        "REST API"
                                }
                        )
                );


                // =====================================================
                // DOMAIN 4 - DATA SCIENCE
                // =====================================================

                CAREERS.put(
                        "Data Scientist",
                        career(
                                "Data Scientist",
                                "Use statistics, programming and machine learning to solve data problems.",
                                req(
                                        "Python", 90,
                                        "Statistics", 85,
                                        "Probability", 75,
                                        "Pandas", 85,
                                        "NumPy", 80,
                                        "SQL", 75,
                                        "Machine Learning", 80,
                                        "Data Visualization", 75
                                ),
                                new String[]{
                                        "Data Scientist",
                                        "Junior Data Scientist",
                                        "Data Science Intern"
                                },
                                new String[]{
                                        "Python for Data Science",
                                        "Statistics",
                                        "Pandas and NumPy",
                                        "Machine Learning",
                                        "Data Visualization"
                                }
                        )
                );


                CAREERS.put(
                        "Data Analyst",
                        career(
                                "Data Analyst",
                                "Analyze data and generate useful business insights.",
                                req(
                                        "SQL", 85,
                                        "Excel", 85,
                                        "Statistics", 75,
                                        "Python", 65,
                                        "Pandas", 70,
                                        "Data Visualization", 80,
                                        "Power BI", 75
                                ),
                                new String[]{
                                        "Data Analyst",
                                        "Business Analyst",
                                        "Reporting Analyst"
                                },
                                new String[]{
                                        "Advanced SQL",
                                        "Excel Analytics",
                                        "Statistics",
                                        "Power BI",
                                        "Python and Pandas"
                                }
                        )
                );


                // =====================================================
                // DOMAIN 5 - ARTIFICIAL INTELLIGENCE
                // =====================================================

                CAREERS.put(
                        "AI Engineer",
                        career(
                                "AI Engineer",
                                "Develop intelligent applications using artificial intelligence techniques.",
                                req(
                                        "Python", 90,
                                        "Artificial Intelligence", 90,
                                        "Machine Learning", 85,
                                        "Deep Learning", 80,
                                        "Statistics", 75,
                                        "TensorFlow", 75,
                                        "PyTorch", 75
                                ),
                                new String[]{
                                        "AI Engineer",
                                        "Artificial Intelligence Developer",
                                        "AI Research Engineer"
                                },
                                new String[]{
                                        "Artificial Intelligence",
                                        "Machine Learning",
                                        "Deep Learning",
                                        "TensorFlow",
                                        "PyTorch"
                                }
                        )
                );


                CAREERS.put(
                        "Generative AI Engineer",
                        career(
                                "Generative AI Engineer",
                                "Build applications using large language models and generative AI technologies.",
                                req(
                                        "Python", 85,
                                        "Artificial Intelligence", 85,
                                        "Machine Learning", 80,
                                        "Large Language Models", 90,
                                        "Prompt Engineering", 85,
                                        "API Development", 75
                                ),
                                new String[]{
                                        "Generative AI Engineer",
                                        "LLM Engineer",
                                        "AI Application Developer"
                                },
                                new String[]{
                                        "Generative AI",
                                        "Large Language Models",
                                        "Prompt Engineering",
                                        "AI APIs",
                                        "AI Application Development"
                                }
                        )
                );


                // =====================================================
                // DOMAIN 6 - MACHINE LEARNING
                // =====================================================

                CAREERS.put(
                        "Machine Learning Engineer",
                        career(
                                "Machine Learning Engineer",
                                "Design and deploy machine learning models.",
                                req(
                                        "Python", 90,
                                        "Machine Learning", 90,
                                        "Statistics", 80,
                                        "Pandas", 80,
                                        "NumPy", 80,
                                        "Scikit-learn", 85,
                                        "Deep Learning", 75
                                ),
                                new String[]{
                                        "Machine Learning Engineer",
                                        "ML Engineer",
                                        "ML Developer"
                                },
                                new String[]{
                                        "Python",
                                        "Statistics",
                                        "Machine Learning",
                                        "Scikit-learn",
                                        "Deep Learning"
                                }
                        )
                );


                // =====================================================
                // DOMAIN 7 - CYBERSECURITY
                // =====================================================

                CAREERS.put(
                        "Cybersecurity Analyst",
                        career(
                                "Cybersecurity Analyst",
                                "Monitor systems and protect organizations against security threats.",
                                req(
                                        "Cybersecurity", 90,
                                        "Computer Networks", 85,
                                        "Operating System", 75,
                                        "Linux", 80,
                                        "Network Security", 80,
                                        "SIEM", 70,
                                        "Incident Response", 75
                                ),
                                new String[]{
                                        "Cybersecurity Analyst",
                                        "Security Analyst",
                                        "SOC Analyst"
                                },
                                new String[]{
                                        "Cybersecurity Fundamentals",
                                        "Network Security",
                                        "Linux Security",
                                        "SIEM",
                                        "Incident Response"
                                }
                        )
                );


                CAREERS.put(
                        "Ethical Hacker",
                        career(
                                "Ethical Hacker",
                                "Identify and report security vulnerabilities in computer systems.",
                                req(
                                        "Cybersecurity", 90,
                                        "Ethical Hacking", 95,
                                        "Penetration Testing", 90,
                                        "Linux", 85,
                                        "Network Security", 85,
                                        "Web Security", 85,
                                        "Cryptography", 70
                                ),
                                new String[]{
                                        "Ethical Hacker",
                                        "Penetration Tester",
                                        "Security Consultant"
                                },
                                new String[]{
                                        "Ethical Hacking",
                                        "Penetration Testing",
                                        "Web Security",
                                        "Network Security",
                                        "Cryptography"
                                }
                        )
                );


                // =====================================================
                // DOMAIN 8 - CLOUD COMPUTING
                // =====================================================

                CAREERS.put(
                        "AWS Cloud Engineer",
                        career(
                                "AWS Cloud Engineer",
                                "Design and manage cloud applications using Amazon Web Services.",
                                req(
                                        "AWS", 90,
                                        "Cloud Computing", 85,
                                        "Linux", 75,
                                        "Computer Networks", 75,
                                        "Docker", 70,
                                        "Terraform", 70,
                                        "Cloud Security", 70
                                ),
                                new String[]{
                                        "AWS Cloud Engineer",
                                        "Cloud Developer",
                                        "Cloud Administrator"
                                },
                                new String[]{
                                        "AWS Fundamentals",
                                        "AWS Architecture",
                                        "Linux",
                                        "Docker",
                                        "Terraform"
                                }
                        )
                );


                CAREERS.put(
                        "Cloud Architect",
                        career(
                                "Cloud Architect",
                                "Design scalable and secure cloud infrastructure.",
                                req(
                                        "AWS", 85,
                                        "Azure", 80,
                                        "Cloud Architecture", 95,
                                        "Cloud Computing", 90,
                                        "Computer Networks", 85,
                                        "Cloud Security", 85,
                                        "Terraform", 75
                                ),
                                new String[]{
                                        "Cloud Architect",
                                        "Solutions Architect",
                                        "Cloud Consultant"
                                },
                                new String[]{
                                        "Cloud Architecture",
                                        "AWS",
                                        "Azure",
                                        "Cloud Security",
                                        "Infrastructure as Code"
                                }
                        )
                );


                // =====================================================
                // DOMAIN 9 - DEVOPS
                // =====================================================

                CAREERS.put(
                        "DevOps Engineer",
                        career(
                                "DevOps Engineer",
                                "Automate software development, testing and deployment processes.",
                                req(
                                        "Linux", 85,
                                        "Git", 85,
                                        "Docker", 85,
                                        "Kubernetes", 80,
                                        "Jenkins", 75,
                                        "CI/CD", 90,
                                        "Terraform", 75,
                                        "Shell Scripting", 75
                                ),
                                new String[]{
                                        "DevOps Engineer",
                                        "DevOps Developer",
                                        "Release Engineer"
                                },
                                new String[]{
                                        "Linux",
                                        "Git",
                                        "Docker",
                                        "Kubernetes",
                                        "CI/CD",
                                        "Terraform"
                                }
                        )
                );


                // =====================================================
                // DOMAIN 10 - DATABASE
                // =====================================================

                CAREERS.put(
                        "Database Administrator",
                        career(
                                "Database Administrator",
                                "Manage, secure and optimize organizational databases.",
                                req(
                                        "SQL", 90,
                                        "DBMS", 90,
                                        "MySQL", 80,
                                        "PostgreSQL", 80,
                                        "Oracle", 80,
                                        "Database Design", 85,
                                        "Database Security", 80
                                ),
                                new String[]{
                                        "Database Administrator",
                                        "Database Engineer",
                                        "Database Specialist"
                                },
                                new String[]{
                                        "Advanced SQL",
                                        "Database Administration",
                                        "Database Design",
                                        "Database Security",
                                        "Performance Tuning"
                                }
                        )
                );


                // =====================================================
                // DOMAIN 11 - DATA ENGINEERING
                // =====================================================

                CAREERS.put(
                        "Data Engineer",
                        career(
                                "Data Engineer",
                                "Build data pipelines and systems for large-scale data processing.",
                                req(
                                        "Python", 80,
                                        "SQL", 90,
                                        "DBMS", 80,
                                        "Data Structures", 70,
                                        "AWS", 70,
                                        "Git", 70
                                ),
                                new String[]{
                                        "Data Engineer",
                                        "Big Data Engineer",
                                        "Data Pipeline Developer"
                                },
                                new String[]{
                                        "Advanced SQL",
                                        "Python for Data Engineering",
                                        "Data Warehousing",
                                        "Cloud Computing",
                                        "ETL Development"
                                }
                        )
                );


                // =====================================================
                // DOMAIN 12 - NETWORKING
                // =====================================================

                CAREERS.put(
                        "Network Engineer",
                        career(
                                "Network Engineer",
                                "Design and maintain reliable computer networks.",
                                req(
                                        "Computer Networks", 95,
                                        "TCP/IP", 90,
                                        "Routing", 85,
                                        "Switching", 85,
                                        "Cisco", 85,
                                        "Network Security", 75,
                                        "Linux", 65
                                ),
                                new String[]{
                                        "Network Engineer",
                                        "Network Administrator",
                                        "Network Specialist"
                                },
                                new String[]{
                                        "Computer Networks",
                                        "TCP/IP",
                                        "Routing and Switching",
                                        "Cisco Networking",
                                        "Network Security"
                                }
                        )
                );


                // =====================================================
                // DOMAIN 13 - SOFTWARE TESTING
                // =====================================================

                CAREERS.put(
                        "Software Tester",
                        career(
                                "Software Tester",
                                "Validate software quality through manual and automated testing.",
                                req(
                                        "Manual Testing", 90,
                                        "Test Case Design", 85,
                                        "Bug Tracking", 80,
                                        "SQL", 60,
                                        "Git", 50
                                ),
                                new String[]{
                                        "QA Tester",
                                        "Software Test Engineer",
                                        "Manual Tester"
                                },
                                new String[]{
                                        "Software Testing Fundamentals",
                                        "Test Case Design",
                                        "Bug Tracking",
                                        "SQL Testing",
                                        "Agile Testing"
                                }
                        )
                );


                CAREERS.put(
                        "Automation Test Engineer",
                        career(
                                "Automation Test Engineer",
                                "Develop automated testing solutions for software applications.",
                                req(
                                        "Java", 70,
                                        "Selenium", 90,
                                        "SQL", 65,
                                        "API Testing", 80,
                                        "Postman", 80,
                                        "TestNG", 75,
                                        "Git", 65
                                ),
                                new String[]{
                                        "Automation Tester",
                                        "SDET",
                                        "Test Automation Engineer"
                                },
                                new String[]{
                                        "Selenium",
                                        "Java Automation",
                                        "API Testing",
                                        "Postman",
                                        "TestNG"
                                }
                        )
                );


                // =====================================================
                // DOMAIN 14 - UI/UX DESIGN
                // =====================================================

                CAREERS.put(
                        "UI UX Designer",
                        career(
                                "UI UX Designer",
                                "Design user-friendly digital products and experiences.",
                                req(
                                        "UI Design", 90,
                                        "UX Design", 90,
                                        "Figma", 90,
                                        "Wireframing", 85,
                                        "Prototyping", 85,
                                        "User Research", 80
                                ),
                                new String[]{
                                        "UI Designer",
                                        "UX Designer",
                                        "Product Designer"
                                },
                                new String[]{
                                        "UI Design",
                                        "UX Design",
                                        "Figma",
                                        "Wireframing",
                                        "Prototyping",
                                        "User Research"
                                }
                        )
                );


                // =====================================================
                // DOMAIN 15 - GAME DEVELOPMENT
                // =====================================================

                CAREERS.put(
                        "Game Developer",
                        career(
                                "Game Developer",
                                "Design and develop interactive games.",
                                req(
                                        "C++", 80,
                                        "C#", 85,
                                        "Unity", 90,
                                        "Game Physics", 80,
                                        "3D Mathematics", 70,
                                        "OOP", 80
                                ),
                                new String[]{
                                        "Game Developer",
                                        "Unity Developer",
                                        "Game Programmer"
                                },
                                new String[]{
                                        "C# Programming",
                                        "Unity",
                                        "Game Physics",
                                        "3D Mathematics",
                                        "Game Development"
                                }
                        )
                );


                // =====================================================
                // DOMAIN 16 - BLOCKCHAIN
                // =====================================================

                CAREERS.put(
                        "Blockchain Developer",
                        career(
                                "Blockchain Developer",
                                "Develop decentralized applications and blockchain solutions.",
                                req(
                                        "Blockchain", 90,
                                        "Solidity", 90,
                                        "Ethereum", 85,
                                        "Smart Contracts", 90,
                                        "Web3", 80,
                                        "Cryptography", 75
                                ),
                                new String[]{
                                        "Blockchain Developer",
                                        "Smart Contract Developer",
                                        "Web3 Developer"
                                },
                                new String[]{
                                        "Blockchain Fundamentals",
                                        "Solidity",
                                        "Ethereum",
                                        "Smart Contracts",
                                        "Web3 Development"
                                }
                        )
                );


                // =====================================================
                // DOMAIN 17 - IOT
                // =====================================================

                CAREERS.put(
                        "IoT Developer",
                        career(
                                "IoT Developer",
                                "Develop connected systems using sensors and internet technologies.",
                                req(
                                        "Python", 70,
                                        "C", 80,
                                        "IoT", 90,
                                        "Arduino", 80,
                                        "Raspberry Pi", 80,
                                        "MQTT", 75,
                                        "Computer Networks", 70
                                ),
                                new String[]{
                                        "IoT Developer",
                                        "IoT Engineer",
                                        "IoT Application Developer"
                                },
                                new String[]{
                                        "IoT Fundamentals",
                                        "Arduino",
                                        "Raspberry Pi",
                                        "MQTT",
                                        "IoT Networking"
                                }
                        )
                );


                // =====================================================
                // DOMAIN 18 - EMBEDDED SYSTEMS
                // =====================================================

                CAREERS.put(
                        "Embedded Systems Developer",
                        career(
                                "Embedded Systems Developer",
                                "Develop software for embedded devices and hardware systems.",
                                req(
                                        "C", 95,
                                        "C++", 80,
                                        "Embedded Systems", 90,
                                        "Microcontrollers", 90,
                                        "Electronics", 75,
                                        "Operating System", 70
                                ),
                                new String[]{
                                        "Embedded Developer",
                                        "Firmware Engineer",
                                        "Embedded Software Engineer"
                                },
                                new String[]{
                                        "Advanced C",
                                        "Embedded Systems",
                                        "Microcontrollers",
                                        "Firmware Development",
                                        "Electronics"
                                }
                        )
                );


                // =====================================================
                // DOMAIN 19 - ROBOTICS
                // =====================================================

                CAREERS.put(
                        "Robotics Engineer",
                        career(
                                "Robotics Engineer",
                                "Design intelligent robotic systems and automation solutions.",
                                req(
                                        "Python", 80,
                                        "C++", 85,
                                        "Robotics", 90,
                                        "ROS", 85,
                                        "Computer Vision", 75,
                                        "Control Systems", 80,
                                        "Mathematics", 75
                                ),
                                new String[]{
                                        "Robotics Engineer",
                                        "Robotics Software Engineer",
                                        "Automation Engineer"
                                },
                                new String[]{
                                        "Robotics",
                                        "C++",
                                        "ROS",
                                        "Computer Vision",
                                        "Control Systems"
                                }
                        )
                );


                // =====================================================
                // DOMAIN 20 - BUSINESS ANALYSIS
                // =====================================================

                CAREERS.put(
                        "Business Analyst",
                        career(
                                "Business Analyst",
                                "Analyze business requirements and translate them into technical solutions.",
                                req(
                                        "Business Analysis", 90,
                                        "Requirement Analysis", 90,
                                        "SQL", 65,
                                        "Excel", 80,
                                        "Communication", 90,
                                        "Problem Solving", 85,
                                        "Documentation", 80
                                ),
                                new String[]{
                                        "Business Analyst",
                                        "Systems Analyst",
                                        "Requirements Analyst"
                                },
                                new String[]{
                                        "Business Analysis",
                                        "Requirement Engineering",
                                        "SQL",
                                        "Excel Analytics",
                                        "Business Communication"
                                }
                        )
                );


                // =====================================================
                // DOMAIN 21 - PRODUCT MANAGEMENT
                // =====================================================

                CAREERS.put(
                        "Product Manager",
                        career(
                                "Product Manager",
                                "Manage product strategy, customer needs and product development.",
                                req(
                                        "Product Management", 90,
                                        "Market Research", 80,
                                        "Business Strategy", 85,
                                        "Communication", 90,
                                        "Leadership", 85,
                                        "Agile", 80
                                ),
                                new String[]{
                                        "Product Manager",
                                        "Associate Product Manager",
                                        "Product Owner"
                                },
                                new String[]{
                                        "Product Management",
                                        "Market Research",
                                        "Product Strategy",
                                        "Agile",
                                        "Leadership"
                                }
                        )
                );


                // =====================================================
                // DOMAIN 22 - DIGITAL MARKETING
                // =====================================================

                CAREERS.put(
                        "Digital Marketing Specialist",
                        career(
                                "Digital Marketing Specialist",
                                "Create and manage digital marketing campaigns.",
                                req(
                                        "Digital Marketing", 90,
                                        "SEO", 85,
                                        "SEM", 80,
                                        "Content Marketing", 80,
                                        "Social Media Marketing", 85,
                                        "Google Analytics", 80
                                ),
                                new String[]{
                                        "Digital Marketing Specialist",
                                        "Digital Marketing Executive",
                                        "Marketing Analyst"
                                },
                                new String[]{
                                        "Digital Marketing",
                                        "SEO",
                                        "SEM",
                                        "Content Marketing",
                                        "Google Analytics"
                                }
                        )
                );


                // =====================================================
                // DOMAIN 23 - FINANCE AND FINTECH
                // =====================================================

                CAREERS.put(
                        "Financial Data Analyst",
                        career(
                                "Financial Data Analyst",
                                "Analyze financial data to support business and investment decisions.",
                                req(
                                        "Python", 70,
                                        "SQL", 80,
                                        "Excel", 90,
                                        "Statistics", 80,
                                        "Financial Analysis", 90,
                                        "Financial Modeling", 80,
                                        "Data Visualization", 75
                                ),
                                new String[]{
                                        "Financial Data Analyst",
                                        "Investment Data Analyst",
                                        "Finance Analyst"
                                },
                                new String[]{
                                        "Financial Analysis",
                                        "Advanced Excel",
                                        "Financial Modeling",
                                        "SQL",
                                        "Data Visualization"
                                }
                        )
                );


                // =====================================================
                // DOMAIN 24 - PROJECT MANAGEMENT
                // =====================================================

                CAREERS.put(
                        "Project Manager",
                        career(
                                "Project Manager",
                                "Plan and manage technology projects from initiation to completion.",
                                req(
                                        "Project Management", 95,
                                        "Leadership", 90,
                                        "Communication", 90,
                                        "Risk Management", 80,
                                        "Time Management", 90,
                                        "Agile", 80
                                ),
                                new String[]{
                                        "Project Manager",
                                        "IT Project Manager",
                                        "Technical Project Manager"
                                },
                                new String[]{
                                        "Project Management",
                                        "Agile",
                                        "Risk Management",
                                        "Leadership",
                                        "Time Management"
                                }
                        )
                );


                // =====================================================
                // DOMAIN 25 - AGILE AND SCRUM
                // =====================================================

                CAREERS.put(
                        "Scrum Master",
                        career(
                                "Scrum Master",
                                "Facilitate Agile teams and help organizations follow Scrum practices.",
                                req(
                                        "Scrum", 95,
                                        "Agile", 95,
                                        "Leadership", 85,
                                        "Communication", 90,
                                        "Team Management", 85,
                                        "Project Management", 75
                                ),
                                new String[]{
                                        "Scrum Master",
                                        "Agile Coach",
                                        "Agile Project Coordinator"
                                },
                                new String[]{
                                        "Agile Methodology",
                                        "Scrum Framework",
                                        "Team Leadership",
                                        "Sprint Planning",
                                        "Agile Project Management"
                                }
                )
        );
    }
}