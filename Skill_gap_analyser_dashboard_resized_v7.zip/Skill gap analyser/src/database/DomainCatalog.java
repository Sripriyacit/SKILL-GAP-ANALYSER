package database;

import java.util.ArrayList;
import java.util.List;

/**
 * Central registry of every domain available inside the
 * Placement, Startup and Higher Studies modules.
 */
public final class DomainCatalog {

    private DomainCatalog() {
    }

    public static final String PLACEMENT = "placement";
    public static final String STARTUP = "startup";
    public static final String HIGHER_STUDY = "higherstudy";

    private static final List<Domain> PLACEMENT_DOMAINS = new ArrayList<>();
    private static final List<Domain> STARTUP_DOMAINS = new ArrayList<>();
    private static final List<Domain> HIGHER_STUDY_DOMAINS = new ArrayList<>();

    static {

        // =====================================================
        // PLACEMENT DOMAINS
        // =====================================================

        PLACEMENT_DOMAINS.add(new Domain(
                "software-development",
                "Software Development",
                "Build applications and systems using core programming, data structures and databases.",
                new String[]{"Java", "DSA", "SQL"},
                "Software Developer (SDE-1)",
                "Technical Support Engineer",
                70
        ));

        PLACEMENT_DOMAINS.add(new Domain(
                "web-development",
                "Web Development",
                "Design and build responsive, interactive websites and web applications.",
                new String[]{"HTML", "CSS", "JavaScript"},
                "Front-End Developer",
                "Web Content & QA Associate",
                70
        ));

        PLACEMENT_DOMAINS.add(new Domain(
                "data-science",
                "Data Science & AI",
                "Analyse data and build predictive models using Python, statistics and machine learning.",
                new String[]{"Python", "Statistics", "Machine Learning"},
                "Data Analyst / Junior Data Scientist",
                "Business Intelligence Executive",
                70
        ));

        PLACEMENT_DOMAINS.add(new Domain(
                "cybersecurity",
                "Cybersecurity",
                "Protect systems, networks and data from digital threats and attacks.",
                new String[]{"Networking", "Linux", "Security Fundamentals"},
                "SOC / Security Analyst (Trainee)",
                "IT Support & Network Administrator",
                70
        ));

        PLACEMENT_DOMAINS.add(new Domain(
                "cloud-devops",
                "Cloud Computing & DevOps",
                "Deploy, automate and manage applications on modern cloud infrastructure.",
                new String[]{"Cloud Computing", "DevOps Tools", "Linux"},
                "Cloud / DevOps Engineer (Trainee)",
                "System Administrator",
                70
        ));

        PLACEMENT_DOMAINS.add(new Domain(
                "mobile-development",
                "Mobile App Development",
                "Design and build mobile applications that connect to real-world data through APIs.",
                new String[]{"Java", "Mobile UI/UX", "REST APIs"},
                "Mobile App Developer (Trainee)",
                "QA Tester - Mobile Apps",
                70
        ));

        PLACEMENT_DOMAINS.add(new Domain(
                "ui-ux-design",
                "UI/UX Design",
                "Research, wireframe and design digital products people enjoy using.",
                new String[]{"Wireframing & Prototyping", "Visual Design Principles", "Product Thinking"},
                "UI/UX Designer (Junior)",
                "Graphic / Visual Designer",
                70
        ));

        PLACEMENT_DOMAINS.add(new Domain(
                "business-analyst",
                "Business Analyst",
                "Bridge business needs and technical teams using data and clear communication.",
                new String[]{"SQL", "Business Operations", "Communication & Pitching"},
                "Business Analyst (Trainee)",
                "Operations Associate",
                70
        ));

        PLACEMENT_DOMAINS.add(new Domain(
                "digital-marketing-placement",
                "Digital Marketing",
                "Plan and run online campaigns that grow a brand's audience and revenue.",
                new String[]{"Digital Marketing", "Communication & Pitching", "Statistics"},
                "Digital Marketing Executive",
                "Social Media / Content Associate",
                70
        ));

        PLACEMENT_DOMAINS.add(new Domain(
                "software-testing",
                "Software Testing & QA",
                "Verify that software works correctly and reliably before it reaches users.",
                new String[]{"Programming Basics", "SQL", "Software Testing"},
                "QA / Test Engineer (Trainee)",
                "Manual Tester",
                70
        ));

        PLACEMENT_DOMAINS.add(new Domain(
                "it-infrastructure",
                "IT Infrastructure & Support",
                "Keep networks, servers and cloud systems running smoothly for an organisation.",
                new String[]{"Networking", "Linux", "Cloud Computing"},
                "IT Infrastructure Engineer (Trainee)",
                "Desktop Support Engineer",
                70
        ));

        // =====================================================
        // STARTUP DOMAINS
        // =====================================================

        STARTUP_DOMAINS.add(new Domain(
                "tech-startup",
                "Tech / Product Startup",
                "Build a technology product or app-based startup from the ground up.",
                new String[]{"Product Thinking", "Programming Basics", "Digital Marketing"},
                "Tech Founder / Product Builder",
                "Early Employee at a Tech Startup",
                65
        ));

        STARTUP_DOMAINS.add(new Domain(
                "ecommerce",
                "E-commerce & D2C",
                "Sell products directly to consumers online under your own brand.",
                new String[]{"Digital Marketing", "Financial Planning", "Business Operations"},
                "E-commerce Entrepreneur",
                "E-commerce Operations Executive",
                65
        ));

        STARTUP_DOMAINS.add(new Domain(
                "fintech",
                "FinTech Startup",
                "Build technology-driven financial products and services.",
                new String[]{"Financial Planning", "Programming Basics", "Business Operations"},
                "FinTech Founder",
                "Financial / Business Analyst at a FinTech Firm",
                65
        ));

        STARTUP_DOMAINS.add(new Domain(
                "service-startup",
                "Service-Based Startup (EdTech / Consulting)",
                "Launch a service or knowledge-based business such as EdTech or consulting.",
                new String[]{"Communication & Pitching", "Business Operations", "Digital Marketing"},
                "Service Startup Founder",
                "Business Development Executive",
                65
        ));

        STARTUP_DOMAINS.add(new Domain(
                "agritech-startup",
                "AgriTech Startup",
                "Use technology and better operations to solve problems in farming and agriculture.",
                new String[]{"Business Operations", "Financial Planning", "Product Thinking"},
                "AgriTech Founder",
                "Field Operations Lead at an AgriTech Startup",
                65
        ));

        STARTUP_DOMAINS.add(new Domain(
                "healthtech-startup",
                "HealthTech Startup",
                "Build products and services that improve access to healthcare.",
                new String[]{"Product Thinking", "Programming Basics", "Communication & Pitching"},
                "HealthTech Founder",
                "Product Associate at a HealthTech Startup",
                65
        ));

        STARTUP_DOMAINS.add(new Domain(
                "social-impact-startup",
                "Social Impact / NGO Startup",
                "Build a mission-driven organisation that solves a social or environmental problem.",
                new String[]{"Communication & Pitching", "Business Operations", "Digital Marketing"},
                "Social Enterprise Founder",
                "Program Coordinator (Non-profit Sector)",
                65
        ));

        STARTUP_DOMAINS.add(new Domain(
                "franchise-retail",
                "Franchise / Retail Business",
                "Start and run a retail outlet or franchise of an established brand.",
                new String[]{"Financial Planning", "Business Operations", "Digital Marketing"},
                "Franchise / Retail Business Owner",
                "Store / Operations Manager",
                65
        ));

        // =====================================================
        // HIGHER STUDY DOMAINS
        // =====================================================

        HIGHER_STUDY_DOMAINS.add(new Domain(
                "engineering-pg",
                "Engineering (M.Tech via GATE)",
                "Pursue postgraduate engineering studies through the GATE examination.",
                new String[]{"Quantitative Aptitude", "Core Engineering Concepts", "Logical Reasoning"},
                "M.Tech via GATE",
                "Campus Placement + GATE as Backup",
                70
        ));

        HIGHER_STUDY_DOMAINS.add(new Domain(
                "management-pg",
                "Management (MBA via CAT/MAT)",
                "Pursue an MBA to build management, strategy and leadership skills.",
                new String[]{"Quantitative Aptitude", "Verbal Ability", "Logical Reasoning"},
                "MBA via CAT / MAT / CMAT",
                "Start Career Now, Pursue Executive MBA Later",
                70
        ));

        HIGHER_STUDY_DOMAINS.add(new Domain(
                "science-pg",
                "Science (M.Sc / PhD via CSIR-NET)",
                "Pursue advanced, research-oriented studies in the pure sciences.",
                new String[]{"Core Science Concepts", "Quantitative Aptitude", "Logical Reasoning"},
                "M.Sc / PhD via CSIR-NET or GATE",
                "Research / Lab Assistant Role",
                70
        ));

        HIGHER_STUDY_DOMAINS.add(new Domain(
                "study-abroad",
                "Study Abroad (MS via GRE/IELTS)",
                "Pursue a Master's degree overseas through GRE and English proficiency exams.",
                new String[]{"Verbal Ability", "Quantitative Aptitude", "English Proficiency"},
                "MS Abroad via GRE + IELTS/TOEFL",
                "MS / M.Tech in India as Backup",
                70
        ));

        HIGHER_STUDY_DOMAINS.add(new Domain(
                "law-pg",
                "Law (LLB/LLM via CLAT)",
                "Pursue legal studies through national law entrance examinations.",
                new String[]{"Verbal Ability", "Logical Reasoning", "English Proficiency"},
                "Law (LLB/LLM) via CLAT/LSAT",
                "Legal Assistant / Paralegal Role",
                70
        ));

        HIGHER_STUDY_DOMAINS.add(new Domain(
                "medical-pg",
                "Medical (NEET-PG)",
                "Pursue postgraduate medical specialisation through NEET-PG.",
                new String[]{"Core Science Concepts", "Logical Reasoning", "Quantitative Aptitude"},
                "Medical PG via NEET-PG",
                "Allied Healthcare Role",
                70
        ));

        HIGHER_STUDY_DOMAINS.add(new Domain(
                "design-pg",
                "Design (M.Des via NID/UCEED)",
                "Pursue a postgraduate design degree through national design entrance exams.",
                new String[]{"Wireframing & Prototyping", "Visual Design Principles", "Logical Reasoning"},
                "M.Des via NID/UCEED",
                "Junior Designer Role",
                70
        ));

        HIGHER_STUDY_DOMAINS.add(new Domain(
                "computer-applications-pg",
                "Computer Applications (MCA via NIMCET)",
                "Pursue a Master's in Computer Applications through national entrance exams.",
                new String[]{"Quantitative Aptitude", "Logical Reasoning", "Programming Basics"},
                "MCA via NIMCET",
                "IT Support / Junior Developer Role",
                70
        ));
    }

    public static List<Domain> getDomains(String module) {

        if (PLACEMENT.equals(module)) {
            return PLACEMENT_DOMAINS;
        }

        if (STARTUP.equals(module)) {
            return STARTUP_DOMAINS;
        }

        if (HIGHER_STUDY.equals(module)) {
            return HIGHER_STUDY_DOMAINS;
        }

        return new ArrayList<>();
    }

    public static Domain findDomain(String module, String key) {

        for (Domain domain : getDomains(module)) {

            if (domain.getKey().equalsIgnoreCase(key)) {
                return domain;
            }
        }

        return null;
    }
}
