package service;

import java.io.PrintStream;
import model.Skill;
import model.Student;

public class SkillAnalyzer {
    public SkillAnalyzer() {
    }

    public double average(Student var1) {
        if (var1.getSkills().isEmpty()) {
            return (double)0.0F;
        } else {
            int var2 = 0;

            for(Skill var4 : var1.getSkills()) {
                var2 += var4.getSkillScore();
            }

            return (double)var2 / (double)var1.getSkills().size();
        }
    }

    public Skill bestSkill(Student var1) {
        Skill var2 = null;

        for(Skill var4 : var1.getSkills()) {
            if (var2 == null || var4.getSkillScore() > var2.getSkillScore()) {
                var2 = var4;
            }
        }

        return var2;
    }

    public void analyze(Student var1) {
        System.out.println("\n========== CURRENT SKILL PROFILE ==========");
        if (var1.getSkills().isEmpty()) {
            System.out.println("No skills entered.");
        } else {
            for(Skill var3 : var1.getSkills()) {
                System.out.printf("%-25s %3d/100%n", var3.getSkillName(), var3.getSkillScore());
            }

            double var5 = this.average(var1);
            Skill var4 = this.bestSkill(var1);
            System.out.printf("\nPersonal Skill Average : %.2f/100%n", var5);
            PrintStream var10000 = System.out;
            String var10001 = var4.getSkillName();
            var10000.println("Strongest Skill        : " + var10001 + " (" + var4.getSkillScore() + ")");
            var10000 = System.out;
            var10001 = this.level(var5);
            var10000.println("Performance Level      : " + var10001);
        }
    }

    public String level(double var1) {
        if (var1 >= (double)80.0F) {
            return "Excellent";
        } else if (var1 >= (double)65.0F) {
            return "Good";
        } else {
            return var1 >= (double)50.0F ? "Developing" : "Needs Improvement";
        }
    }

    public void analyze(Student var1, String var2) {
        System.out.println("Department: " + var2);
        this.analyze(var1);
    }
}
