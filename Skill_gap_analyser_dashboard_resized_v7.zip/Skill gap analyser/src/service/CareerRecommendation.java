
        package service;

import database.SkillDatabase;
import interfaces.Recommendation;
import model.Career;
import model.SkillGap;
import model.Student;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Provides career, job, course, and skill recommendations
 * based on the student's current skills and career goals.
 */
public class CareerRecommendation implements Recommendation {

    private final GapAnalyzer gapAnalyzer;

    /**
     * Constructor.
     */
    public CareerRecommendation() {
        gapAnalyzer = new GapAnalyzer();
    }


    // =========================================================
    // RECOMMEND JOB ROLES
    // =========================================================

    @Override
    public void recommendJobs(Student student) {

        System.out.println();
        System.out.println(
                "========== RECOMMENDED JOB ROLES =========="
        );

        if (student == null) {

            System.out.println(
                    "Student information is not available."
            );

            return;
        }

        Career career =
                getTargetCareer(student);

        if (career == null) {
            return;
        }

        System.out.println(
                "Target Career: "
                        + career.getName()
        );

        System.out.println();

        /*
         * getJobs() returns a String[] array.
         * Therefore, use length == 0 instead of isEmpty().
         */
        if (career.getJobs() == null ||
                career.getJobs().length == 0) {

            System.out.println(
                    "No job roles available for this career."
            );

            return;
        }

        System.out.println(
                "Recommended Job Roles:"
        );

        for (String job :
                career.getJobs()) {

            System.out.println(
                    "- " + job
            );
        }
    }


    // =========================================================
    // RECOMMEND COURSES
    // =========================================================

    @Override
    public void recommendCourses(Student student) {

        System.out.println();
        System.out.println(
                "========== PERSONALIZED COURSES =========="
        );

        if (student == null) {

            System.out.println(
                    "Student information is not available."
            );

            return;
        }

        Career career =
                getTargetCareer(student);

        if (career == null) {
            return;
        }

        /*
         * Find skill gaps between the student's
         * current skills and career requirements.
         */
        List<SkillGap> skillGaps =
                gapAnalyzer.findSkillGaps(
                        student,
                        career
                );

        /*
         * Sort skill gaps from highest to lowest.
         */
        skillGaps.sort(
                Comparator.comparingInt(
                        SkillGap::getGap
                ).reversed()
        );

        System.out.println(
                "Recommended Learning Areas:"
        );

        int count = 0;

        /*
         * Display the top five skills
         * that need improvement.
         */
        for (SkillGap skillGap :
                skillGaps) {

            if (skillGap.getGap() > 0 &&
                    count < 5) {

                count++;

                System.out.println(
                        count
                                + ". Improve "
                                + skillGap.getSkillName()
                                + " by "
                                + skillGap.getGap()
                                + " points"
                );
            }
        }

        if (count == 0) {

            System.out.println(
                    "You have met all required "
                            + "skill targets."
            );

            System.out.println(
                    "Focus on advanced projects, "
                            + "certifications, and "
                            + "interview preparation."
            );
        }

        System.out.println();
        System.out.println(
                "Suggested Courses:"
        );

        /*
         * getCourses() returns a String[] array.
         * Therefore, use length == 0 instead of isEmpty().
         */
        if (career.getCourses() == null ||
                career.getCourses().length == 0) {

            System.out.println(
                    "- No specific courses available."
            );

            return;
        }

        for (String course :
                career.getCourses()) {

            System.out.println(
                    "- " + course
            );
        }
    }


    // =========================================================
    // RECOMMEND PRIORITY SKILLS
    // =========================================================

    @Override
    public void recommendSkills(Student student) {

        System.out.println();
        System.out.println(
                "========== PRIORITY SKILLS TO LEARN =========="
        );

        if (student == null) {

            System.out.println(
                    "Student information is not available."
            );

            return;
        }

        Career career =
                getTargetCareer(student);

        if (career == null) {
            return;
        }

        /*
         * Find the student's skill gaps.
         */
        List<SkillGap> skillGaps =
                gapAnalyzer.findSkillGaps(
                        student,
                        career
                );

        /*
         * Sort the largest skill gaps first.
         */
        skillGaps.sort(
                Comparator.comparingInt(
                        SkillGap::getGap
                ).reversed()
        );

        int count = 1;

        /*
         * Display all skills that need improvement.
         */
        for (SkillGap skillGap :
                skillGaps) {

            if (skillGap.getGap() > 0) {

                System.out.println(
                        count
                                + ". "
                                + skillGap.getSkillName()
                                + " - Current: "
                                + skillGap.getCurrentScore()
                                + " | Target: "
                                + skillGap.getRequiredScore()
                                + " | Gap: "
                                + skillGap.getGap()
                );

                count++;
            }
        }

        /*
         * If no skill gaps exist.
         */
        if (count == 1) {

            System.out.println(
                    "Excellent! All required skills "
                            + "meet the target level."
            );
        }
    }


    // =========================================================
    // RECOMMEND BEST-FIT CAREERS
    // =========================================================

    @Override
    public void recommendCareer(Student student) {

        System.out.println();
        System.out.println(
                "========== CAREER FIT RECOMMENDATIONS =========="
        );

        if (student == null) {

            System.out.println(
                    "Student information is not available."
            );

            return;
        }

        /*
         * Store all career names and their
         * readiness percentages.
         */
        List<CareerScore> careerScores =
                new ArrayList<>();

        /*
         * Calculate the student's readiness
         * for every career in the database.
         */
        for (Career career :
                SkillDatabase.getCareers()) {

            double readiness =
                    gapAnalyzer.readiness(
                            student,
                            career
                    );

            careerScores.add(
                    new CareerScore(
                            career.getName(),
                            readiness
                    )
            );
        }

        /*
         * Sort careers from highest readiness
         * percentage to lowest.
         */
        careerScores.sort(
                Comparator.comparingDouble(
                        CareerScore::getReadiness
                ).reversed()
        );

        if (careerScores.isEmpty()) {

            System.out.println(
                    "No career recommendations available."
            );

            return;
        }

        /*
         * Display the top three career matches.
         */
        int limit =
                Math.min(
                        3,
                        careerScores.size()
                );

        System.out.println(
                "Based on your current skills, "
                        + "your best career matches are:"
        );

        System.out.println();

        for (int i = 0;
             i < limit;
             i++) {

            CareerScore score =
                    careerScores.get(i);

            System.out.printf(
                    "%d. %-25s %.2f%%%n",
                    i + 1,
                    score.getCareerName(),
                    score.getReadiness()
            );
        }

        /*
         * Display the best career match.
         */
        CareerScore bestMatch =
                careerScores.get(0);

        System.out.println();

        System.out.println(
                "---------------------------------------------"
        );

        System.out.println(
                "BEST CAREER MATCH"
        );

        System.out.println(
                "Career: "
                        + bestMatch.getCareerName()
        );

        System.out.printf(
                "Readiness: %.2f%%%n",
                bestMatch.getReadiness()
        );

        System.out.println(
                "---------------------------------------------"
        );
    }


    // =========================================================
    // GET TARGET CAREER
    // =========================================================

    /**
     * Finds the career selected by the student.
     *
     * @param student the student
     * @return the selected Career object, or null
     */
    private Career getTargetCareer(
            Student student
    ) {

        String targetCareer =
                student.getTargetCareer();

        if (targetCareer == null ||
                targetCareer.trim().isEmpty()) {

            System.out.println(
                    "No target career has been selected."
            );

            return null;
        }

        Career career =
                SkillDatabase.getCareer(
                        targetCareer
                );

        if (career == null) {

            System.out.println(
                    "Career not found: "
                            + targetCareer
            );

            return null;
        }

        return career;
    }


    // =========================================================
    // CAREER SCORE CLASS
    // =========================================================

    /**
     * Stores a career name and its readiness score.
     */
    private static class CareerScore {

        private final String careerName;
        private final double readiness;


        /**
         * Constructor.
         *
         * @param careerName career name
         * @param readiness readiness percentage
         */
        public CareerScore(
                String careerName,
                double readiness
        ) {

            this.careerName =
                    careerName;

            this.readiness =
                    readiness;
        }


        /**
         * Returns the career name.
         *
         * @return career name
         */
        public String getCareerName() {

            return careerName;
        }


        /**
         * Returns the readiness score.
         *
         * @return readiness percentage
         */
        public double getReadiness() {

            return readiness;
        }
    }
}
