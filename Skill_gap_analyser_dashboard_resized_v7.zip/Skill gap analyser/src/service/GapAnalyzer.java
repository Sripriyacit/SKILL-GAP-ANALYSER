package service;

import model.Career;
import model.Skill;
import model.SkillGap;
import model.Student;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Analyzes the difference between a student's
 * current skills and the skills required for a career.
 */
public class GapAnalyzer {


    // =========================================================
    // FIND SKILL GAPS
    // =========================================================

    /**
     * Finds all skill gaps for a student based on
     * the requirements of the selected career.
     *
     * @param student the student
     * @param career the target career
     * @return list of SkillGap objects
     */
    public List<SkillGap> findSkillGaps(
            Student student,
            Career career
    ) {

        /*
         * IMPORTANT:
         * Use List<SkillGap>, not raw List.
         *
         * This fixes:
         * java.lang.Object cannot be converted to model.SkillGap
         */
        List<SkillGap> gaps =
                new ArrayList<>();

        if (student == null ||
                career == null) {

            return gaps;
        }

        /*
         * Get required skills from the career.
         */
        Map<String, Integer> requiredSkills =
                career.getRequiredSkills();

        if (requiredSkills == null) {

            return gaps;
        }

        /*
         * Check every skill required by the career.
         */
        for (
                Map.Entry<String, Integer> entry
                : requiredSkills.entrySet()
        ) {

            String skillName =
                    entry.getKey();

            int requiredScore =
                    entry.getValue();

            /*
             * Find the student's current
             * proficiency for this skill.
             */
            int currentScore =
                    getStudentSkillScore(
                            student,
                            skillName
                    );

            /*
             * Create SkillGap object.
             */
            SkillGap skillGap =
                    new SkillGap(
                            skillName,
                            currentScore,
                            requiredScore
                    );

            /*
             * Add the SkillGap object
             * to the typed list.
             */
            gaps.add(skillGap);
        }

        return gaps;
    }


    // =========================================================
    // GET STUDENT SKILL SCORE
    // =========================================================

    /**
     * Finds the current proficiency score
     * of a particular skill for a student.
     *
     * @param student the student
     * @param skillName skill to search for
     * @return current skill score, or 0 if not found
     */
    private int getStudentSkillScore(
            Student student,
            String skillName
    ) {

        if (student == null ||
                skillName == null) {

            return 0;
        }

        /*
         * Get the student's skills.
         *
         * This assumes Student has:
         *
         * getSkills()
         *
         * returning List<Skill>.
         */
        List<Skill> skills =
                student.getSkills();

        if (skills == null) {

            return 0;
        }

        /*
         * Search for the required skill.
         */
        for (Skill skill : skills) {

            if (skill != null &&
                    skill.getSkillName()
                            .equalsIgnoreCase(
                                    skillName
                            )) {

                return skill.getSkillScore();
            }
        }

        /*
         * Student does not have the skill.
         * Therefore current score is 0.
         */
        return 0;
    }


    // =========================================================
    // READINESS
    // =========================================================

    /**
     * Calculates the student's readiness percentage
     * for a particular career.
     *
     * @param student the student
     * @param career the career
     * @return readiness percentage from 0 to 100
     */
    public double readiness(
            Student student,
            Career career
    ) {

        if (student == null ||
                career == null) {

            return 0.0;
        }

        Map<String, Integer> requiredSkills =
                career.getRequiredSkills();

        if (requiredSkills == null ||
                requiredSkills.isEmpty()) {

            return 0.0;
        }

        double totalRequired =
                0.0;

        double totalAchieved =
                0.0;

        /*
         * Calculate weighted readiness
         * based on required skill levels.
         */
        for (
                Map.Entry<String, Integer> entry
                : requiredSkills.entrySet()
        ) {

            String skillName =
                    entry.getKey();

            int requiredScore =
                    entry.getValue();

            int currentScore =
                    getStudentSkillScore(
                            student,
                            skillName
                    );

            /*
             * Do not allow current score
             * to exceed the required score
             * when calculating readiness.
             */
            int achievedScore =
                    Math.min(
                            currentScore,
                            requiredScore
                    );

            totalRequired +=
                    requiredScore;

            totalAchieved +=
                    achievedScore;
        }

        if (totalRequired == 0) {

            return 0.0;
        }

        return
                (totalAchieved /
                        totalRequired)
                        * 100.0;
    }


    // =========================================================
    // PRINT GAP REPORT
    // =========================================================

    /**
     * Prints a detailed skill gap report.
     *
     * @param student the student
     * @param career target career
     */
    public void printGapReport(
            Student student,
            Career career
    ) {

        System.out.println();

        System.out.println(
                "========== SKILL GAP REPORT =========="
        );

        if (student == null ||
                career == null) {

            System.out.println(
                    "Unable to generate gap report."
            );

            return;
        }

        List<SkillGap> gaps =
                findSkillGaps(
                        student,
                        career
                );

        if (gaps.isEmpty()) {

            System.out.println(
                    "No skill requirements found."
            );

            return;
        }

        System.out.println(
                "Target Career: "
                        + career.getName()
        );

        System.out.println();

        System.out.printf(
                "%-25s %-10s %-10s %-10s %-20s%n",
                "Skill",
                "Current",
                "Required",
                "Gap",
                "Status"
        );

        System.out.println(
                "-----------------------------------------------------------------------"
        );

        /*
         * Because gaps is List<SkillGap>,
         * every gap is automatically treated
         * as a SkillGap object.
         */
        for (SkillGap gap : gaps) {

            System.out.printf(
                    "%-25s %-10d %-10d %-10d %-20s%n",
                    gap.getSkillName(),
                    gap.getCurrent(),
                    gap.getRequired(),
                    gap.getGap(),
                    gap.getStatus()
            );
        }

        System.out.println();

        double readiness =
                readiness(
                        student,
                        career
                );

        System.out.printf(
                "Overall Career Readiness: %.2f%%%n",
                readiness
        );
    }
}
