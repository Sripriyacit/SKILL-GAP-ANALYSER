package service;

import model.Skill;

import java.util.Comparator;
import java.util.List;

public class SkillSorter {

    /**
     * Sorts the student's skills based on proficiency score.
     * Skills with the highest score appear first.
     *
     * @param skills list of skills to be sorted
     */
    public void sortSkills(
            List<Skill> skills
    ) {

        if (skills == null || skills.isEmpty()) {

            System.out.println(
                    "No skills available to sort."
            );

            return;
        }

        skills.sort(
                Comparator.comparingInt(
                        Skill::getSkillScore
                ).reversed()
        );
    }
}

