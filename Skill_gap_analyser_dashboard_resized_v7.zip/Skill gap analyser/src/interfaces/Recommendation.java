package interfaces;
import model.Student;

public interface Recommendation {

    /**
     * Recommends suitable job roles
     * based on the student's selected career.
     *
     * @param student the student
     */
    void recommendJobs(Student student);


    /**
     * Recommends courses based on
     * the student's skill gaps.
     *
     * @param student the student
     */
    void recommendCourses(Student student);


    /**
     * Recommends priority skills that
     * the student should learn or improve.
     *
     * @param student the student
     */
    void recommendSkills(Student student);


    /**
     * Recommends the best-fit careers
     * based on the student's current skills.
     *
     * @param student the student
     */
    void recommendCareer(Student student);
}

