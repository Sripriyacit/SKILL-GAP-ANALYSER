package util;

import java.util.Collections;
import java.util.Comparator;
import model.Skill;
import model.Student;

public class Statistics {
    public Statistics() {
    }

    public static class SkillStatistics {
        public SkillStatistics() {
        }

        public static void calculate(Student var0) {
            if (var0.getSkills().isEmpty()) {
                System.out.println("No skill statistics available.");
            } else {
                Skill var1 = (Skill)Collections.max(var0.getSkills(), Comparator.comparingInt(Skill::getSkillScore));
                Skill var2 = (Skill)Collections.min(var0.getSkills(), Comparator.comparingInt(Skill::getSkillScore));
                double var3 = var0.getSkills().stream().mapToInt(Skill::getSkillScore).average().orElse((double)0.0F);
                System.out.printf("\nStatistics -> Average: %.2f | Best: %s (%d) | Lowest: %s (%d)%n", var3, var1.getSkillName(), var1.getSkillScore(), var2.getSkillName(), var2.getSkillScore());
            }
        }
    }
}
