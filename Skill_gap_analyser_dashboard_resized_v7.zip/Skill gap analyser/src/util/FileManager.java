package util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;

public class FileManager {
    public FileManager() {
    }

    public void saveReport(String var1) {
        this.saveReport(var1, "StudentReport.txt");
    }

    public void saveReport(String var1, String var2) {
        try {
            BufferedWriter var3 = new BufferedWriter(new FileWriter(var2));

            try {
                var3.write(var1);
                PrintStream var10000 = System.out;
                File var10001 = new File(var2);
                var10000.println("\nReport saved successfully to: " + var10001.getAbsolutePath());
            } catch (Throwable var7) {
                try {
                    var3.close();
                } catch (Throwable var6) {
                    var7.addSuppressed(var6);
                }

                throw var7;
            }

            var3.close();
        } catch (IOException var8) {
            System.out.println("Could not save report: " + var8.getMessage());
        }

    }
}
