
        package util;

import database.SkillDatabase;

import java.util.Comparator;
import java.util.List;
import java.util.Objects;

import model.Career;
import model.Skill;
import model.SkillGap;
import model.Student;

import service.GapAnalyzer;
import service.SkillAnalyzer;

/**
 * Generates a detailed skill gap analysis report
 * for a student.
 */
public class ReportGenerator {

    private final GapAnalyzer gapAnalyzer =
            new GapAnalyzer();

    private final SkillAnalyzer skillAnalyzer =
            new SkillAnalyzer();


    // =========================================================
    // CONSTRUCTOR
    // =========================================================

    public ReportGenerator() {
    }


    // =========================================================
    // GENERATE REPORT
    // =========================================================

    /**
     * Generates a complete skill gap analysis report.
     *
     * @param student student to analyze
     * @return StringBuilder containing the report
     */
    public StringBuilder generateReport(
            Student student
    ) {

        StringBuilder report =
                new StringBuilder();

        if (student == null) {

            report.append(
                    "Student information is not available.\n"
            );

            return report;
        }


        // =====================================================
        // FIND TARGET CAREER
        // =====================================================

        Career career =
                SkillDatabase.getCareer(
                        student.getTargetCareer()
                );


        // =====================================================
        // REPORT HEADER
        // =====================================================

        report.append(
                "==============================================\n"
        );

        report.append(
                "       SKILL GAP ANALYZER - FINAL REPORT\n"
        );

        report.append(
                "==============================================\n"
        );


        // =====================================================
        // STUDENT DETAILS
        // =====================================================

        report.append(
                "Student ID : "
        ).append(
                student.getStudentId()
        ).append('\n');

        report.append(
                "Name       : "
        ).append(
                student.getName()
        ).append('\n');

        report.append(
                "Department : "
        ).append(
                student.getDepartment()
        ).append('\n');

        report.append(
                "College    : "
        ).append(
                student.getCollegeName()
        ).append('\n');

        report.append(
                "Semester   : "
        ).append(
                student.getSemester()
        ).append('\n');

        report.append(
                "CGPA       : "
        ).append(
                student.getCgpa()
        ).append('\n');

        report.append(
                "Career Goal: "
        ).append(
                student.getTargetCareer()
        ).append('\n');


        // =====================================================
        // CURRENT SKILLS
        // =====================================================

        report.append(
                "\nCURRENT SKILLS\n"
        );

        report.append(
                "----------------------------------------------\n"
        );

        if (student.getSkills() == null ||
                student.getSkills().isEmpty()) {

            report.append(
                    "No skills have been entered.\n"
            );

        } else {

            for (Skill skill :
                    student.getSkills()) {

                report.append(
                        String.format(
                                "%-25s %3d/100%n",
                                skill.getSkillName(),
                                skill.getSkillScore()
                        )
                );
            }
        }


        // =====================================================
        // CAREER ANALYSIS
        // =====================================================

        if (career != null) {


            // =================================================
            // CAREER READINESS
            // =================================================

            double readiness =
                    gapAnalyzer.readiness(
                            student,
                            career
                    );

            report.append(
                    "\nCAREER READINESS: "
            ).append(
                    String.format(
                            "%.2f%%",
                            readiness
                    )
            ).append('\n');


            // =================================================
            // SKILL GAP DETAILS
            // =================================================

            report.append(
                    "\nSKILL GAP DETAILS\n"
            );

            report.append(
                    "----------------------------------------------\n"
            );


            /*
             * IMPORTANT:
             *
             * The list is explicitly declared as
             * List<SkillGap>.
             *
             * This fixes:
             *
             * java.lang.Object cannot be converted
             * to model.SkillGap
             */
            List<SkillGap> skillGaps =
                    gapAnalyzer.findSkillGaps(
                            student,
                            career
                    );


            // =================================================
            // DISPLAY SKILL GAPS
            // =================================================

            for (SkillGap skillGap :
                    skillGaps) {

                report.append(
                        String.format(
                                "%-22s Current=%3d "
                                        + "Required=%3d "
                                        + "Gap=%3d "
                                        + "Status=%s%n",

                                skillGap.getSkillName(),

                                skillGap.getCurrent(),

                                skillGap.getRequired(),

                                skillGap.getGap(),

                                skillGap.getStatus()
                        )
                );
            }


            // =================================================
            // LEARNING ROADMAP
            // =================================================

            report.append(
                    "\nLEARNING ROADMAP\n"
            );

            report.append(
                    "----------------------------------------------\n"
            );


            /*
             * Sort the same typed list.
             *
             * The largest skill gaps appear first.
             */
            skillGaps.sort(
                    Comparator.comparingInt(
                            SkillGap::getGap
                    ).reversed()
            );


            int count = 1;


            // =================================================
            // DISPLAY LEARNING ROADMAP
            // =================================================

            for (SkillGap skillGap :
                    skillGaps) {

                if (skillGap.getGap() > 0) {

                    report.append(
                            count++
                    ).append(
                            ". Improve "
                    ).append(
                            skillGap.getSkillName()
                    ).append(
                            " to at least "
                    ).append(
                            skillGap.getRequired()
                    ).append(
                            "/100\n"
                    );
                }
            }


            // =================================================
            // NO SKILL GAPS
            // =================================================

            if (count == 1) {

                report.append(
                        "You meet the target skill levels. "
                                + "Build projects and prepare "
                                + "for interviews.\n"
                );
            }

        } else {

            report.append(
                    "\nCareer information not found.\n"
            );
        }


        // =====================================================
        // PERSONAL SKILL AVERAGE
        // =====================================================

        report.append(
                "\nPersonal Skill Average: "
        ).append(
                String.format(
                        "%.2f",
                        skillAnalyzer.average(student)
                )
        ).append(
                "/100\n"
        );


        // =====================================================
        // REPORT FOOTER
        // =====================================================

        report.append(
                "==============================================\n"
        );

        report.append(
                "             END OF REPORT\n"
        );

        report.append(
                "==============================================\n"
        );


        return report;
    }


    // =========================================================
    // SECURE REPORT
    // =========================================================

    /**
     * Creates a short confidential report.
     *
     * @param student student information
     * @return confidential report
     */
    public StringBuffer secureReport(
            Student student
    ) {

        if (student == null) {

            return new StringBuffer(
                    "Confidential Report\n"
                            + "Student information unavailable."
            );
        }

        return new StringBuffer(
                "Confidential Report\n"
                        + "Student: "
                        + student.getName()
                        + "\nCareer: "
                        + student.getTargetCareer()
        );
    }


    // =========================================================
    // PRINTER CLASS
    // =========================================================

    /**
     * Inner class used to print reports.
     */
    public class Printer {

        public Printer() {

            Objects.requireNonNull(
                    ReportGenerator.this
            );
        }


        /**
         * Prints the generated report.
         *
         * @param report report to print
         */
        public void print(
                StringBuilder report
        ) {

            if (report == null) {

                System.out.println(
                        "No report available."
                );

                return;
            }

            System.out.println(
                    report
            );
        }
    }
}

