package util;

import model.User;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Handles user registration and login, backed by a simple
 * pipe-delimited text file so accounts survive a server restart.
 */
public final class UserStore {

    private static final Path DATA_FILE = Paths.get("data", "users.txt");

    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[\\w.+-]+@[\\w-]+\\.[a-zA-Z]{2,}$");

    private static final Pattern USERNAME_PATTERN =
            Pattern.compile("^[a-zA-Z0-9_]{4,20}$");

    private static final Map<String, User> USERS_BY_USERNAME =
            new LinkedHashMap<>();

    static {
        load();
    }

    private UserStore() {
    }

    // =========================================================
    // RESULT WRAPPER
    // =========================================================

    public static class AuthResult {

        public final boolean success;
        public final String message;
        public final User user;

        public AuthResult(boolean success, String message, User user) {
            this.success = success;
            this.message = message;
            this.user = user;
        }
    }

    // =========================================================
    // REGISTER
    // =========================================================

    public static synchronized AuthResult register(
            String fullName,
            String email,
            String username,
            String password,
            String confirmPassword,
            String age,
            String qualification,
            String collegeName,
            String department,
            String semester,
            String cgpa) {

        fullName = fullName == null ? "" : fullName.trim();
        email = email == null ? "" : email.trim();
        username = username == null ? "" : username.trim();
        password = password == null ? "" : password;
        confirmPassword = confirmPassword == null ? "" : confirmPassword;

        age = age == null ? "" : age.trim();
        qualification = qualification == null ? "" : qualification.trim();
        collegeName = collegeName == null ? "" : collegeName.trim();
        department = department == null ? "" : department.trim();
        semester = semester == null ? "" : semester.trim();
        cgpa = cgpa == null ? "" : cgpa.trim();

        if (fullName.length() < 3) {
            return new AuthResult(false,
                    "Please enter your full name (at least 3 characters).", null);
        }

        if (!EMAIL_PATTERN.matcher(email).matches()) {
            return new AuthResult(false,
                    "Please enter a valid email address.", null);
        }

        if (!USERNAME_PATTERN.matcher(username).matches()) {
            return new AuthResult(false,
                    "Username must be 4-20 characters (letters, numbers, underscore only).",
                    null);
        }

        if (password.length() < 6) {
            return new AuthResult(false,
                    "Password must be at least 6 characters long.", null);
        }

        if (!password.equals(confirmPassword)) {
            return new AuthResult(false,
                    "Passwords do not match.", null);
        }

        int ageValue;

        try {

            ageValue = Integer.parseInt(age);

        } catch (NumberFormatException e) {

            return new AuthResult(false, "Please enter a valid age.", null);
        }

        if (ageValue < 15 || ageValue > 100) {
            return new AuthResult(false, "Age must be between 15 and 100.", null);
        }

        if (qualification.isEmpty()) {
            return new AuthResult(false, "Please select your qualification.", null);
        }

        if (collegeName.length() < 3) {
            return new AuthResult(false,
                    "Please enter your college / institution name.", null);
        }

        if (department.length() < 2) {
            return new AuthResult(false, "Please enter your department.", null);
        }

        if (semester.isEmpty()) {
            return new AuthResult(false,
                    "Please select your current year / semester.", null);
        }

        if (!cgpa.isEmpty()) {

            try {

                double cgpaValue = Double.parseDouble(cgpa);

                if (cgpaValue < 0 || cgpaValue > 10) {
                    return new AuthResult(false,
                            "CGPA must be between 0 and 10 (leave blank if not applicable).", null);
                }

            } catch (NumberFormatException e) {

                return new AuthResult(false,
                        "Please enter a valid CGPA (leave blank if not applicable).", null);
            }
        }

        if (USERS_BY_USERNAME.containsKey(username.toLowerCase())) {
            return new AuthResult(false,
                    "This username is already taken.", null);
        }

        for (User existing : USERS_BY_USERNAME.values()) {
            if (existing.getEmail().equalsIgnoreCase(email)) {
                return new AuthResult(false,
                        "An account with this email already exists.", null);
            }
        }

        User user = new User(
                fullName,
                email,
                username,
                PasswordUtil.hash(password),
                age,
                qualification,
                collegeName,
                department,
                semester,
                cgpa.isEmpty() ? "N/A" : cgpa
        );

        USERS_BY_USERNAME.put(username.toLowerCase(), user);

        persist();

        return new AuthResult(true, "Registration successful. Please log in.", user);
    }

    // =========================================================
    // LOGIN
    // =========================================================

    public static synchronized AuthResult login(String usernameOrEmail, String password) {

        usernameOrEmail = usernameOrEmail == null ? "" : usernameOrEmail.trim();
        password = password == null ? "" : password;

        if (usernameOrEmail.isEmpty() || password.isEmpty()) {
            return new AuthResult(false, "Please enter your username and password.", null);
        }

        User user = USERS_BY_USERNAME.get(usernameOrEmail.toLowerCase());

        if (user == null) {

            for (User candidate : USERS_BY_USERNAME.values()) {
                if (candidate.getEmail().equalsIgnoreCase(usernameOrEmail)) {
                    user = candidate;
                    break;
                }
            }
        }

        if (user == null) {
            return new AuthResult(false, "No account found with that username or email.", null);
        }

        if (!PasswordUtil.matches(password, user.getPasswordHash())) {
            return new AuthResult(false, "Incorrect password. Please try again.", null);
        }

        return new AuthResult(true, "Login successful.", user);
    }

    public static synchronized User findByUsername(String username) {

        if (username == null) {
            return null;
        }

        return USERS_BY_USERNAME.get(username.toLowerCase());
    }

    // =========================================================
    // PERSISTENCE
    // =========================================================
    //
    // Line format (pipe-delimited, 10 fields):
    // username|email|fullName|passwordHash|age|qualification|collegeName|department|semester|cgpa

    private static void load() {

        try {

            if (!Files.exists(DATA_FILE)) {
                return;
            }

            List<String> lines = Files.readAllLines(DATA_FILE, StandardCharsets.UTF_8);

            for (String line : lines) {

                if (line.trim().isEmpty()) {
                    continue;
                }

                String[] parts = line.split("\\|", -1);

                if (parts.length < 4) {
                    continue;
                }

                String age = parts.length > 4 ? parts[4] : "";
                String qualification = parts.length > 5 ? parts[5] : "";
                String collegeName = parts.length > 6 ? parts[6] : "";
                String department = parts.length > 7 ? parts[7] : "";
                String semester = parts.length > 8 ? parts[8] : "";
                String cgpa = parts.length > 9 ? parts[9] : "";

                User user = new User(
                        parts[2], parts[1], parts[0], parts[3],
                        age, qualification, collegeName, department, semester, cgpa
                );

                USERS_BY_USERNAME.put(parts[0].toLowerCase(), user);
            }

        } catch (IOException e) {

            Logger.getInstance().log("Could not load users file: " + e.getMessage());
        }
    }

    private static void persist() {

        try {

            if (DATA_FILE.getParent() != null) {
                Files.createDirectories(DATA_FILE.getParent());
            }

            StringBuilder builder = new StringBuilder();

            for (User user : USERS_BY_USERNAME.values()) {

                builder.append(user.getUsername()).append("|")
                        .append(user.getEmail()).append("|")
                        .append(user.getFullName()).append("|")
                        .append(user.getPasswordHash()).append("|")
                        .append(user.getAge()).append("|")
                        .append(user.getQualification()).append("|")
                        .append(user.getCollegeName()).append("|")
                        .append(user.getDepartment()).append("|")
                        .append(user.getSemester()).append("|")
                        .append(user.getCgpa())
                        .append(System.lineSeparator());
            }

            Files.write(DATA_FILE, builder.toString().getBytes(StandardCharsets.UTF_8));

        } catch (IOException e) {

            Logger.getInstance().log("Could not save users file: " + e.getMessage());
        }
    }
}
