
        package util;

import model.Student;

/**
 * Handles cloning of Student objects.
 */
public class CloneManager {

    /**
     * Creates a clone of the given student.
     *
     * @param student the student to clone
     * @return cloned Student object, or null if student is null
     */
    public Student cloneStudent(Student student) {

        // Check for null input
        if (student == null) {
            return null;
        }

        // Student.clone() does not throw
        // CloneNotSupportedException,
        // so no try-catch is required.
        return student.clone();
    }
}

