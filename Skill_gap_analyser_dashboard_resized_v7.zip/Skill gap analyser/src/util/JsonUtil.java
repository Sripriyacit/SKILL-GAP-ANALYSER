package util;

import java.util.List;

/**
 * Very small helper for hand-building JSON strings without
 * needing an external library, matching the style already
 * used in this project's web layer.
 */
public final class JsonUtil {

    private JsonUtil() {
    }

    public static String esc(String text) {

        if (text == null) {
            return "";
        }

        return text
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", " ")
                .replace("\r", " ")
                .replace("\t", " ");
    }

    public static String quote(String text) {
        return "\"" + esc(text) + "\"";
    }

    public static String stringArray(List<String> values) {

        StringBuilder json = new StringBuilder("[");

        for (int i = 0; i < values.size(); i++) {

            json.append(quote(values.get(i)));

            if (i < values.size() - 1) {
                json.append(",");
            }
        }

        json.append("]");

        return json.toString();
    }
}
