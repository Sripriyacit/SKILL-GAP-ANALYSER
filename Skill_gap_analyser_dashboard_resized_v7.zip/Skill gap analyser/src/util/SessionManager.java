package util;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Keeps track of logged-in users using a simple in-memory
 * token -> username map. The token is stored in the browser
 * as a cookie named SGASESSION.
 */
public final class SessionManager {

    public static final String COOKIE_NAME = "SGASESSION";

    private static final Map<String, String> TOKEN_TO_USERNAME =
            new ConcurrentHashMap<>();

    private SessionManager() {
    }

    public static String createSession(String username) {

        String token = UUID.randomUUID().toString();

        TOKEN_TO_USERNAME.put(token, username);

        return token;
    }

    public static String getUsername(String token) {

        if (token == null) {
            return null;
        }

        return TOKEN_TO_USERNAME.get(token);
    }

    public static void invalidate(String token) {

        if (token != null) {
            TOKEN_TO_USERNAME.remove(token);
        }
    }
}
