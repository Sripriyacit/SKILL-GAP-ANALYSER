package util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Small helper used to hash and verify user passwords
 * using SHA-256 so plain text passwords are never stored.
 */
public final class PasswordUtil {

    private PasswordUtil() {
    }

    public static String hash(String rawPassword) {

        try {

            MessageDigest digest = MessageDigest.getInstance("SHA-256");

            byte[] hashedBytes = digest.digest(
                    rawPassword.getBytes(StandardCharsets.UTF_8)
            );

            StringBuilder hex = new StringBuilder();

            for (byte b : hashedBytes) {

                String piece = Integer.toHexString(0xff & b);

                if (piece.length() == 1) {
                    hex.append('0');
                }

                hex.append(piece);
            }

            return hex.toString();

        } catch (NoSuchAlgorithmException e) {

            throw new RuntimeException(
                    "Unable to hash password", e
            );
        }
    }

    public static boolean matches(String rawPassword, String hashedPassword) {

        if (rawPassword == null || hashedPassword == null) {
            return false;
        }

        return hash(rawPassword).equals(hashedPassword);
    }
}
