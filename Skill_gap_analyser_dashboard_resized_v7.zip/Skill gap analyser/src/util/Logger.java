package util;

public final class Logger {
    private static final Logger INSTANCE = new Logger();

    private Logger() {
    }

    public static Logger getInstance() {
        return INSTANCE;
    }

    public void log(String var1) {
        System.out.println("[LOG] " + var1);
    }
}
