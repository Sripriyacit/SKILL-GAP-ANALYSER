package util;

import exception.InvalidSkillException;

public final class Validation {
    private Validation() {
    }

    public static void validateSkillScore(int var0) throws InvalidSkillException {
        if (var0 < 0 || var0 > 100) {
            throw new InvalidSkillException("Skill score must be between 0 and 100.");
        }
    }

    public static boolean validateCGPA(double var0) {
        return var0 >= (double) 0.0F && var0 <= (double) 10.0F;
    }

    public static boolean validateAge(int var0) {
        return var0 >= 17 && var0 <= 35;
    }

    public static boolean validateSemester(int var0) {
        return var0 >= 1 && var0 <= 8;
    }

    public static boolean validateGender(String gender) {

        if (gender == null || gender.trim().isEmpty()) {
            return false;
        }

        return gender.equalsIgnoreCase("Male")
                || gender.equalsIgnoreCase("Female")
                || gender.equalsIgnoreCase("Other");
    }

        public static boolean isBlank(String var0) {
        return var0 == null || var0.trim().isEmpty();
    }
}
