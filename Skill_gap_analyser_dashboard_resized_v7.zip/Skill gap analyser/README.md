# Skill Gap Analyzer

A Java web application that assesses a user's skills and recommends the
best-fit path across four modules: **Placement**, **Government Exams**,
**Startups**, and **Higher Studies**.

## How to run

1. Open the project folder ("Skill gap analyser") in IntelliJ IDEA (or any
   Java IDE) as an existing project. It already has a `.iml` / `.idea`
   configuration.
2. Make sure the **working directory** for the run configuration is the
   project root (the folder containing `src/`), since the server reads its
   frontend files from `src/web/frontend/...` and stores user accounts in
   `data/users.txt`, both relative to that directory. IntelliJ's default
   working directory is already the project root, so this normally needs no
   change.
3. Run the `web.WebServer` class (`src/web/WebServer.java`). It has a
   `main` method that starts a plain Java `HttpServer` on port `8080`
   (no external dependencies / frameworks required).
4. Open a browser at **http://localhost:8080**.

## User flow

1. **Home page** → click **Get Started**.
2. **Register** a new account (full name, email, username, password, age, and
   an academic profile — qualification, current year/semester, college name,
   department and optional CGPA) — all fields are validated both in the
   browser and on the server.
3. **Log in** with your new username/password. A session cookie keeps you
   logged in.
4. **Dashboard** — choose one of the four modules:
   - **Placement** → pick a domain (Software Development, Web Development,
     Data Science & AI, Cybersecurity, Cloud Computing & DevOps) → choose
     which of its skills to be assessed on → take the multiple-choice
     assessment → get a full skill-gap report: overall score, per-skill
     gap breakdown, a recommended job role, an alternate job role, a
     study plan (resource + tip per weak skill), and general career tips.
   - **Government Exams** → browse **Central** and **State** government
     job opportunities, each with department, qualification, age limit
     and selection process.
   - **Startups** → same assessment engine as Placement, but for startup
     paths (Tech/Product, E-commerce & D2C, FinTech, Service-based), with
     a founder role, an alternate role, and startup-specific tips.
   - **Higher Studies** → same assessment engine again, for postgraduate
     paths (Engineering/GATE, Management/CAT, Science/CSIR-NET, Study
     Abroad/GRE), recommending the right entrance-exam path.

## Project structure (new additions)

```
src/
  model/
    User.java            - registered user
    GovJob.java           - a government job + eligibility
  util/
    PasswordUtil.java     - SHA-256 password hashing
    UserStore.java        - registration/login + file persistence
    SessionManager.java   - login sessions (cookie based)
    JsonUtil.java          - small JSON string builder
  database/
    Domain.java            - one path inside a module (skills, roles)
    DomainCatalog.java      - all Placement/Startup/Higher-Study domains
    QuestionBank.java       - MCQ bank (26 skills, 5 questions each)
    SkillResourceCatalog.java - study resource + tip per skill
    GovJobCatalog.java       - Central & State government jobs
  web/
    WebServer.java          - HTTP routing (auth, domains, questions, submit, govt jobs)
    AssessmentEngine.java   - scores answers, computes the gap report
    AssessmentResult.java   - the report model + JSON serializer
    Question.java            - existing question model (reused)
    frontend/
      index.html, login.html, register.html, dashboard.html
      placement.html, startup.html, higher-studies.html
      skills.html, assessment.html, result.html
      govt.html
      css/style.css, js/auth.js
```

The original CLI program (`src/Main.java` and the `model`/`service`
classes it uses) is untouched and still works as a separate console-based
demo of the underlying skill-gap logic.

## Notes

- Accounts are stored in `data/users.txt` (created automatically on first
  registration) as `username|email|fullName|passwordHash|age|qualification|
  collegeName|department|semester|cgpa`. Passwords are
  never stored in plain text.
- This is a self-contained project: no external libraries or database are
  required, only the JDK's built-in `com.sun.net.httpserver`.
- Government exam eligibility details are general guidelines; they vary by
  year/state/category, so the app reminds users to check the official
  notification before applying.
